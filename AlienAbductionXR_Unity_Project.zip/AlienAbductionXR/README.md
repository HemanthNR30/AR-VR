# 🛸 ALIEN ABDUCTION XR
### Unity AR/VR Cinematic Experience | 2-Minute Immersive Sequence

![Unity](https://img.shields.io/badge/Unity-2022.3%20LTS-blue)
![URP](https://img.shields.io/badge/URP-14.0.9-cyan)
![AR Foundation](https://img.shields.io/badge/AR%20Foundation-5.1.0-green)
![XR Toolkit](https://img.shields.io/badge/XR%20Toolkit-2.5.2-orange)
![License](https://img.shields.io/badge/License-MIT-white)

---

## 🎬 EXPERIENCE OVERVIEW

A fully cinematic 2-minute alien abduction sequence in AR/VR:

| Phase | Duration | What Happens |
|---|---|---|
| 1 — Deep Space Approach | 12s | Spaceship dot of light grows from deep space |
| 2 — Solar System Entry | 8s | Earth + Moon visible, ship accelerating |
| 3 — Earth Orbit | 10s | Orbits Earth, scouting the target |
| 4 — Atmospheric Entry | 10s | Fiery re-entry, camera shake, heat distortion |
| 5 — Descent | 10s | Slow dramatic approach over house |
| 6 — Hover — Lock On | 8s | Eerie hover, humans panic |
| 7 — Tractor Beam Active | 6s | Cyan beam opens, blue light floods scene |
| 8 — Abduction | 18s | 3 humans spiral up into ship one by one |
| 9 — Ascent | 10s | Ship climbs away |
| 10 — Warp Departure | 5s | Streak jump to space |

---

## 📁 PROJECT STRUCTURE

```
AlienAbductionXR/
├── Assets/
│   ├── Scripts/
│   │   ├── Core/
│   │   │   ├── GameManager.cs                ← Singleton master controller
│   │   │   ├── ExperienceSettings.cs         ← ScriptableObject with all tunable values
│   │   │   ├── AbductionSequenceDirector.cs  ← Full 10-phase sequence director
│   │   │   ├── SpaceshipController.cs        ← All ship movement + FX + beam
│   │   │   ├── HumanAbductionBehavior.cs     ← NPC panic + lift + abduction
│   │   │   ├── EnvironmentManager.cs         ← Sky, ground, clouds, fog, lighting
│   │   │   ├── PostProcessingController.cs   ← URP bloom/vignette/color grading
│   │   │   ├── AudioManager.cs               ← Full spatial audio system
│   │   │   └── CinematicCameraController.cs  ← Shake, FOV, look-at
│   │   ├── AR/
│   │   │   └── ARExperienceManager.cs        ← AR Foundation placement
│   │   ├── VR/
│   │   │   └── VRExperienceManager.cs        ← Meta Quest + PC VR haptics
│   │   └── UI/
│   │       └── HUDController.cs              ← Cinematic HUD telemetry
│   ├── Shaders/
│   │   ├── SpaceshipShaders.shader           ← TractorBeam + Hull URP shaders
│   │   └── EffectShaders.shader              ← WarpStreak + HolographicHuman shaders
│   ├── Editor/
│   │   └── SceneSetupTool.cs                 ← Auto-wire scene references
│   ├── Scenes/              ← Create your scenes here
│   ├── Prefabs/             ← Drop prefabs here
│   ├── Materials/           ← Assign shaders to materials
│   └── ScriptableObjects/   ← ExperienceSettings asset goes here
└── Packages/
    └── manifest.json        ← All required packages
```

---

## ⚙️ SETUP GUIDE

### Step 1: Unity Version
Use **Unity 2022.3 LTS** or **Unity 6.0+**

### Step 2: Install Packages
Open `Packages/manifest.json` — all packages are already listed.
Unity will auto-download them on project open.

Or install manually via Package Manager:
- AR Foundation 5.x
- ARKit XR Plugin (iOS)
- ARCore XR Plugin (Android)
- XR Interaction Toolkit 2.5+
- Universal Render Pipeline 14.x
- TextMeshPro
- ProBuilder (for making cone/house meshes)
- AI Navigation (NavMesh for humans)
- Cinemachine (optional, for cinematic cameras)

### Step 3: URP Setup
1. `Edit > Project Settings > Graphics`
2. Assign a **URP Asset** (create one if none exists)
3. Enable: Post Processing, Soft Shadows, SSAO, Screen Space Reflections

### Step 4: XR Plugin Management
`Edit > Project Settings > XR Plugin Management`
- iOS: Enable **ARKit**
- Android: Enable **ARCore**  
- Meta Quest: Enable **Oculus** + set Android as platform
- PC VR: Enable **OpenXR**

---

## 🏗️ SCENE HIERARCHY

Create a new scene and build this hierarchy:

```
Scene
├── ──── MANAGERS ────
│   ├── GameManager (GameManager.cs)
│   ├── AudioManager (AudioManager.cs)
│   └── PostProcessVolume (PostProcessingController.cs + Volume)
│
├── ──── XR ────
│   ├── AR Session (ARSession + ARInputManager)         ← AR only
│   ├── AR Session Origin (ARExperienceManager.cs)       ← AR only
│   │   └── AR Camera (Camera + TrackedPoseDriver)
│   └── XR Origin (VRExperienceManager.cs)               ← VR only
│       └── Camera Offset
│           └── Main Camera
│
├── ──── SPACESHIP ────
│   └── SpaceshipRoot (SpaceshipController.cs + SpaceshipFXSetup.cs)
│       ├── ShipMesh (your UFO 3D model here)
│       │   └── Dome (glass dome mesh)
│       ├── Engines/
│       │   ├── Engine_1 → Engine_2 → Engine_3 → Engine_4
│       ├── RunningLights/
│       │   ├── Light_Red → Light_White → Light_Blue → etc.
│       ├── TractorBeamOrigin (Transform, center bottom)
│       ├── TractorBeamCone (Cone mesh + TractorBeam material)
│       ├── TractorBeamLight (Point Light, Cyan)
│       ├── TractorBeamParticles (ParticleSystem)
│       ├── TractorBeamImpact (ParticleSystem, for ground)
│       ├── EntryFireFX (ParticleSystem, fire/glow)
│       ├── AbductionSwirlFX (ParticleSystem)
│       ├── WarpStreak (ParticleSystem + WarpStreak.shader)
│       └── WarpTrail (TrailRenderer)
│
├── ──── ENVIRONMENT ────
│   └── EnvironmentManager (EnvironmentManager.cs)
│       ├── EarthCenter (empty Transform, world origin)
│       ├── GroundSceneRoot (all ground content)
│       │   ├── HouseRoot (your house 3D model)
│       │   │   ├── House_Mesh
│       │   │   ├── WindowLights/ (Point lights for windows)
│       │   │   └── Chimney
│       │   ├── GroundPlane (large plane mesh)
│       │   ├── Trees/ (tree silhouette meshes)
│       │   ├── Road (plane mesh)
│       │   ├── StreetLamp1 / StreetLamp2 (Point lights)
│       │   └── Humans/ (human NPCs - see below)
│       ├── CelestialObjects/
│       │   ├── EarthOrb (sphere with Earth material)
│       │   └── MoonOrb (sphere with Moon material)
│       ├── CloudObjects/ (simple cloud meshes)
│       ├── CityLights (plane with glow texture)
│       ├── EntryFirePlane (quad, atmospheric entry FX)
│       └── DustParticles (ParticleSystem)
│
└── ──── HUMANS ────
    ├── Human_1 (HumanAbductionBehavior.cs + Animator + NavMeshAgent + Rigidbody)
    │   ├── SkinnedMeshRenderer (your character mesh)
    │   ├── TractorGlowFX (ParticleSystem)
    │   ├── AbductionSparksFX (ParticleSystem)
    │   ├── DisappearFX (ParticleSystem)
    │   └── BeamLight (Point Light, cyan)
    ├── Human_2 (same setup)
    └── Human_3 (same setup)
```

---

## 🎭 HUMAN ANIMATOR SETUP

Each Human needs an Animator Controller with these states:

```
[Entry] → [Idle]
[Idle] ──(IsPanicking=true)──→ [Panic Run]
[Panic Run] ──(IsStruggling=true)──→ [Struggle]  
[Struggle] ──(IsLifted=true)──→ [Lifted/Float]
```

**Free animations from Mixamo.com:**
- Idle: "Breathing Idle"
- Panic Run: "Running" (speed 1.2)
- Struggle: "Shaking" or "Dying"
- Lifted: "Falling Idle" or "Floating"

**Parameters needed:**
- IsPanicking (Bool)
- IsStruggling (Bool)
- IsLifted (Bool)
- FearBlend (Float, for blend tree)

---

## 🎨 MATERIALS SETUP

### Tractor Beam Material
1. Create Material → Shader: `AlienAbductionXR/TractorBeam`
2. Assign to TractorBeamCone mesh
3. Settings: Beam Color (0.1, 0.85, 1.0, 0.35), Scan Speed 2.5

### Spaceship Hull Material
1. Create Material → Shader: `AlienAbductionXR/SpaceshipHull`
2. Assign to main ship mesh
3. Settings: Base Color (#1A2035), Metallic 0.9, Smoothness 0.7

### Holographic Human Material
1. Create Material → Shader: `AlienAbductionXR/HolographicHuman`
2. Assign as `tractorGlowMaterial` on each HumanAbductionBehavior
3. Settings: Holo Color (0.1, 0.9, 1.0, 1.0), Dissolve starts at 0

### Warp Streak Material
1. Create Material → Shader: `AlienAbductionXR/WarpStreak`
2. Assign to WarpStreak particle system's renderer
3. Enable "Additive" blending

---

## 🔧 EDITOR TOOL

After placing all GameObjects, use the auto-wiring tool:
**Window > AlienAbductionXR > Scene Setup Tool**

Click **"AUTO-SETUP ENTIRE SCENE"** to wire all references automatically.
Then click **"Validate Scene"** to check for missing references.

---

## 📱 AR BUILD (iOS / Android)

```
File → Build Settings → iOS or Android
Player Settings:
  - Camera Usage Description: "Required for AR experience"
  - Microphone Usage Description: "Required for XR audio"
  - Min iOS: 14.0 / Min Android API: 26
XR Plugin Management → ARKit (iOS) / ARCore (Android)
Build and deploy to device
```

**AR Interaction:**
- Point phone at flat surface (floor, table)
- Tap to place the scene
- Three scale modes: Table-Top (4cm), Room Scale (25cm), Full Scale

---

## 🥽 VR BUILD

### Meta Quest 2/3
```
File → Build Settings → Android
XR Plugin Management → Oculus
Player Settings → Texture Compression: ASTC
Target: Quest 2/3
Build APK → Install via Meta Quest Developer Hub or ADB
```

### PC VR (SteamVR)
```
File → Build Settings → Windows
XR Plugin Management → OpenXR
Add OpenXR Feature Set → Mock HMD for testing
Build .exe → Run with headset connected
```

---

## 🔊 RECOMMENDED FREE AUDIO

Download from **freesound.org** or **zapsplat.com**:

| Slot | Search Term |
|---|---|
| engineApproachLoop | "deep space drone loop" |
| engineHoverLoop | "UFO hover electric hum" |
| atmosphericEntryBoom | "explosion boom whoosh fire" |
| tractorBeamActivate | "sci-fi beam charge up" |
| tractorBeamLoop | "electric field energy loop" |
| abductionSwoosh | "sci-fi whoosh ascending" |
| warpCharge | "sci-fi warp charge" |
| warpJump | "sci-fi jump hyper speed" |
| groundRumble | "earthquake low rumble bass" |
| nightAmbience | "night crickets wind ambient" |
| screamClips | "human scream fear" (x3) |

---

## 🌟 REALISM TIPS

### Lighting
- Use **HDRI Skies** from Polyhaven.com (free)
- Enable **Volumetric Lighting** (URP 14+ or HDRP)
- Add **Lens Flares** on spaceship running lights
- Use **Real-time Global Illumination** for beam light on ground

### 3D Models (Free)
- **Spaceship**: Sketchfab → "Flying Saucer UFO" (filter: free)
- **House**: Unity Asset Store → "FREE Suburban House"
- **Trees**: SpeedTree Subscription or use Unity's built-in
- **Humans**: Mixamo.com → export FBX + animations for free

### Performance (Mobile/Quest)
- Max 65k polys per mesh on Quest 2
- Use **LOD Groups** on all large meshes
- Bake ambient occlusion textures
- Set shadow distance to 30m max
- Use **GPU Instancing** on tree meshes

---

## 📋 CHECKLIST BEFORE BUILD

- [ ] All packages installed (check Console for errors)
- [ ] URP Asset assigned in Project Settings > Graphics
- [ ] XR Plugin enabled for target platform
- [ ] ExperienceSettings ScriptableObject created and assigned
- [ ] Scene Setup Tool run (Window > AlienAbductionXR)
- [ ] Validate Scene returns 0 issues
- [ ] NavMesh baked (Window > AI > Navigation > Bake)
- [ ] Human Animator Controllers set up with correct parameters
- [ ] All audio clips assigned in AudioManager
- [ ] Post Processing Volume has all overrides added
- [ ] TractorBeamCone mesh oriented correctly (pointing down)
- [ ] Spaceship starts above scene (in Phase 1 coroutine)

---

## 👨‍💻 QUICK START

1. `git clone https://github.com/YOUR_USERNAME/AlienAbductionXR`
2. Open in Unity 2022.3+
3. Let packages install (~2-5 minutes)
4. Open `Assets/Scenes/MainScene.unity`
5. Run Scene Setup Tool: `Window > AlienAbductionXR > Scene Setup Tool`
6. Press Play to test in Desktop mode
7. Build to device for full AR/VR experience

---

## 📄 LICENSE

MIT License — Free to use, modify, and distribute.

---

*Made with Unity 2022.3 LTS | AR Foundation 5.x | XR Interaction Toolkit 2.5 | URP 14*
