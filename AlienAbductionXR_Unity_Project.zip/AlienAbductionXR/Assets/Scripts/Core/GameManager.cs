using System.Collections;
using UnityEngine;
using UnityEngine.Events;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// GameManager — Singleton master controller.
    /// Manages XR mode selection, scene state, and global events.
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        [Header("XR Mode")]
        public XRMode currentMode = XRMode.AR;

        [Header("Scene References")]
        public SpaceshipController spaceshipController;
        public AbductionSequenceDirector sequenceDirector;
        public EnvironmentManager environmentManager;
        public AudioManager audioManager;
        public CinematicCameraController cameraController;

        [Header("AR / VR Roots")]
        public GameObject arSessionRoot;
        public GameObject vrSessionRoot;
        public GameObject arUI;
        public GameObject vrUI;

        [Header("Events")]
        public UnityEvent OnExperienceStart;
        public UnityEvent OnAbductionBegin;
        public UnityEvent OnAbductionComplete;
        public UnityEvent<AbductionPhase> OnPhaseChanged;

        [Header("Settings")]
        public ExperienceSettings settings;

        private bool _experienceStarted = false;
        private AbductionPhase _currentPhase = AbductionPhase.Idle;

        public AbductionPhase CurrentPhase => _currentPhase;
        public bool ExperienceStarted => _experienceStarted;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        void Start()
        {
            InitializeXRMode();
        }

        // ── XR Mode ───────────────────────────────────────────────────────────

        void InitializeXRMode()
        {
            bool isVRDevice = UnityEngine.XR.XRSettings.isDeviceActive &&
                              UnityEngine.XR.XRSettings.loadedDeviceName.ToLower().Contains("oculus");

            currentMode = isVRDevice ? XRMode.VR : XRMode.AR;

            arSessionRoot?.SetActive(currentMode == XRMode.AR);
            vrSessionRoot?.SetActive(currentMode == XRMode.VR);
            arUI?.SetActive(currentMode == XRMode.AR);
            vrUI?.SetActive(currentMode == XRMode.VR);

            Debug.Log($"[GameManager] XR Mode: {currentMode}");
        }

        // ── Experience Control ─────────────────────────────────────────────────

        public void StartExperience()
        {
            if (_experienceStarted) return;
            _experienceStarted = true;

            OnExperienceStart?.Invoke();
            audioManager?.PlayAmbient();

            StartCoroutine(RunExperience());
        }

        IEnumerator RunExperience()
        {
            yield return new WaitForSeconds(settings.introPauseSeconds);
            sequenceDirector?.BeginSequence();
        }

        public void SetPhase(AbductionPhase newPhase)
        {
            _currentPhase = newPhase;
            OnPhaseChanged?.Invoke(newPhase);

            if (newPhase == AbductionPhase.ActivateTractorBeam)
                OnAbductionBegin?.Invoke();

            if (newPhase == AbductionPhase.Complete)
                OnAbductionComplete?.Invoke();
        }

        public void RestartExperience()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(
                UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
        }
    }

    public enum XRMode { AR, VR, Desktop }

    public enum AbductionPhase
    {
        Idle,
        ApproachFromSpace,
        AtmosphericEntry,
        Descend,
        Hover,
        ActivateTractorBeam,
        AbductHumans,
        Ascend,
        WarpDeparture,
        Complete
    }
}
