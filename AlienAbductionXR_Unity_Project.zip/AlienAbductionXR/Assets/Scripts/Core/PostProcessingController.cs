using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// PostProcessingController
    /// Drives all URP post-processing dynamically during the sequence.
    /// Bloom, vignette, chromatic aberration, color grading, lens distortion,
    /// film grain, depth of field — all cinematically animated.
    /// </summary>
    public class PostProcessingController : MonoBehaviour
    {
        [Header("Volume")]
        public Volume globalVolume;

        [Header("Settings")]
        public ExperienceSettings settings;

        // URP effect components
        private Bloom _bloom;
        private Vignette _vignette;
        private ChromaticAberration _ca;
        private ColorAdjustments _colorAdj;
        private LensDistortion _lensDist;
        private DepthOfField _dof;
        private FilmGrain _grain;
        private PaniniProjection _panini;

        private Coroutine _activeFX;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Awake()
        {
            if (!globalVolume) globalVolume = GetComponent<Volume>();
            var profile = globalVolume.profile;

            profile.TryGet(out _bloom);
            profile.TryGet(out _vignette);
            profile.TryGet(out _ca);
            profile.TryGet(out _colorAdj);
            profile.TryGet(out _lensDist);
            profile.TryGet(out _dof);
            profile.TryGet(out _grain);
            profile.TryGet(out _panini);

            ApplyBaseFilmLook();
        }

        void ApplyBaseFilmLook()
        {
            // Realistic film base — always on
            if (_grain != null)
            {
                _grain.intensity.value = 0.22f;
                _grain.response.value = 0.85f;
                _grain.type.value = FilmGrainLookup.Medium1;
            }
            if (_vignette != null)
            {
                _vignette.intensity.value = 0.3f;
                _vignette.smoothness.value = 0.5f;
                _vignette.color.value = Color.black;
            }
            if (_bloom != null)
            {
                _bloom.threshold.value = 0.9f;
                _bloom.intensity.value = settings.bloomIntensityNormal;
                _bloom.scatter.value = 0.7f;
            }
            if (_colorAdj != null)
            {
                _colorAdj.contrast.value = 8f;
                _colorAdj.saturation.value = -5f;
                _colorAdj.colorFilter.value = new Color(0.95f, 0.97f, 1f); // Slight cold tint
            }
            if (_dof != null)
            {
                _dof.mode.value = DepthOfFieldMode.Bokeh;
                _dof.focusDistance.value = 10f;
                _dof.focalLength.value = 50f;
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  PUBLIC API
        // ══════════════════════════════════════════════════════════════════════

        public void SetSpaceMode()
        {
            StopActiveFX();
            _activeFX = StartCoroutine(LerpToSpaceMode());
        }

        public void TriggerAtmosphericEntry(bool enable)
        {
            StopActiveFX();
            _activeFX = StartCoroutine(enable
                ? LerpToAtmosphericEntry()
                : LerpToNightScene(3f));
        }

        public void TriggerTractorBeam(bool enable)
        {
            StopActiveFX();
            _activeFX = StartCoroutine(enable
                ? LerpToTractorBeam()
                : LerpToNightScene(2f));
        }

        public void TriggerWarpFX()
        {
            StopActiveFX();
            _activeFX = StartCoroutine(WarpEffect());
        }

        // ══════════════════════════════════════════════════════════════════════
        //  FX PROFILES
        // ══════════════════════════════════════════════════════════════════════

        IEnumerator LerpToSpaceMode()
        {
            float duration = 2f, elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                if (_bloom != null) _bloom.intensity.value = Mathf.Lerp(_bloom.intensity.value, 1.5f, t);
                if (_colorAdj != null) _colorAdj.colorFilter.value = Color.Lerp(_colorAdj.colorFilter.value, new Color(0.85f, 0.9f, 1f), t);
                if (_lensDist != null) _lensDist.intensity.value = Mathf.Lerp(_lensDist.intensity.value, 0.1f, t);

                yield return null;
            }
        }

        IEnumerator LerpToAtmosphericEntry()
        {
            // Dramatic orange-red entry effect
            float duration = 1.5f, elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 12f);

                if (_bloom != null)
                {
                    _bloom.intensity.value = Mathf.Lerp(_bloom.intensity.value, settings.bloomIntensityEntry * (0.8f + pulse * 0.4f), t);
                    _bloom.tint.value = Color.Lerp(_bloom.tint.value, new Color(1f, 0.4f, 0.1f), t);
                }
                if (_ca != null) _ca.intensity.value = Mathf.Lerp(_ca.intensity.value, 0.9f, t);
                if (_lensDist != null) _lensDist.intensity.value = Mathf.Lerp(_lensDist.intensity.value, -0.35f, t);
                if (_colorAdj != null)
                {
                    _colorAdj.colorFilter.value = Color.Lerp(_colorAdj.colorFilter.value, new Color(1f, 0.5f, 0.2f), t);
                    _colorAdj.saturation.value = Mathf.Lerp(_colorAdj.saturation.value, -30f, t);
                    _colorAdj.contrast.value = Mathf.Lerp(_colorAdj.contrast.value, 25f, t);
                }
                if (_vignette != null) _vignette.intensity.value = Mathf.Lerp(_vignette.intensity.value, 0.65f, t);
                if (_grain != null) _grain.intensity.value = Mathf.Lerp(_grain.intensity.value, 0.55f, t);

                yield return null;
            }

            // Hold and pulse
            while (_activeFX != null)
            {
                float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 8f);
                if (_bloom != null) _bloom.intensity.value = settings.bloomIntensityEntry * (0.7f + pulse * 0.6f);
                yield return null;
            }
        }

        IEnumerator LerpToTractorBeam()
        {
            float duration = 2f, elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                if (_bloom != null)
                {
                    _bloom.intensity.value = Mathf.Lerp(_bloom.intensity.value, settings.bloomIntensityBeam, t);
                    _bloom.tint.value = Color.Lerp(_bloom.tint.value, settings.tractorBeamColor, t);
                }
                if (_vignette != null) _vignette.intensity.value = Mathf.Lerp(_vignette.intensity.value, settings.vignetteIntensityMax, t);
                if (_ca != null) _ca.intensity.value = Mathf.Lerp(_ca.intensity.value, 0.45f, t);
                if (_colorAdj != null)
                {
                    _colorAdj.colorFilter.value = Color.Lerp(_colorAdj.colorFilter.value, settings.tractorBeamColor * 0.4f + Color.white * 0.6f, t);
                    _colorAdj.saturation.value = Mathf.Lerp(_colorAdj.saturation.value, -20f, t);
                }

                yield return null;
            }

            // Pulse while active
            while (true)
            {
                float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 2.5f);
                if (_bloom != null) _bloom.intensity.value = Mathf.Lerp(settings.bloomIntensityBeam * 0.6f, settings.bloomIntensityBeam * 1.4f, pulse);
                yield return null;
            }
        }

        IEnumerator LerpToNightScene(float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                if (_bloom != null)
                {
                    _bloom.intensity.value = Mathf.Lerp(_bloom.intensity.value, 1.5f, t);
                    _bloom.tint.value = Color.Lerp(_bloom.tint.value, Color.white, t);
                }
                if (_vignette != null) _vignette.intensity.value = Mathf.Lerp(_vignette.intensity.value, settings.vignetteIntensityBase, t);
                if (_ca != null) _ca.intensity.value = Mathf.Lerp(_ca.intensity.value, 0f, t);
                if (_lensDist != null) _lensDist.intensity.value = Mathf.Lerp(_lensDist.intensity.value, 0f, t);
                if (_colorAdj != null)
                {
                    _colorAdj.colorFilter.value = Color.Lerp(_colorAdj.colorFilter.value, Color.white, t);
                    _colorAdj.saturation.value = Mathf.Lerp(_colorAdj.saturation.value, -5f, t);
                    _colorAdj.contrast.value = Mathf.Lerp(_colorAdj.contrast.value, 8f, t);
                }
                if (_grain != null) _grain.intensity.value = Mathf.Lerp(_grain.intensity.value, 0.22f, t);

                yield return null;
            }
        }

        IEnumerator WarpEffect()
        {
            // Fast intense flash then fade
            float duration = 1f, elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float flash = Mathf.Max(0f, 1f - t * 2f);

                if (_bloom != null) _bloom.intensity.value = Mathf.Lerp(_bloom.intensity.value, 15f * flash + 1f, 0.3f);
                if (_lensDist != null) _lensDist.intensity.value = -0.6f * flash;
                if (_ca != null) _ca.intensity.value = flash;

                yield return null;
            }
        }

        void StopActiveFX()
        {
            if (_activeFX != null) { StopCoroutine(_activeFX); _activeFX = null; }
        }
    }
}
