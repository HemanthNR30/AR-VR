using System.Collections;
using UnityEngine;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// CinematicCameraController
    /// Manages camera shake, FOV changes, auto look-at targets,
    /// and cinematic framing during key moments.
    /// Works in both AR (device camera) and VR (HMD camera) modes.
    /// </summary>
    public class CinematicCameraController : MonoBehaviour
    {
        [Header("Camera")]
        public Camera mainCamera;
        public Transform cameraRig; // Parent transform for shake

        [Header("Shake Settings")]
        public float shakeDecaySpeed = 5f;
        public float shakeRotationalAmount = 0.5f;
        public AnimationCurve shakeFalloff = AnimationCurve.EaseInOut(0, 1, 1, 0);

        [Header("FOV")]
        public float baseFOV = 60f;
        public float tractorBeamFOV = 55f;    // Slight zoom during beam
        public float warpFOV = 90f;            // Wide during warp
        public float fovLerpSpeed = 2f;

        [Header("Look At")]
        public float lookAtLerpSpeed = 1.5f;
        public bool enableAutoLookAt = false;

        // ── Private ───────────────────────────────────────────────────────────
        private float _currentShakeIntensity = 0f;
        private float _targetFOV;
        private Transform _lookAtTarget;
        private bool _lookingAt = false;
        private Vector3 _originalRigPos;
        private Quaternion _originalRigRot;
        private Coroutine _shakeCoroutine;
        private Coroutine _fovCoroutine;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Awake()
        {
            if (!mainCamera) mainCamera = Camera.main;
            if (cameraRig) { _originalRigPos = cameraRig.localPosition; _originalRigRot = cameraRig.localRotation; }
            _targetFOV = baseFOV;

            GameManager.Instance?.OnPhaseChanged.AddListener(OnPhaseChanged);
        }

        void Update()
        {
            ProcessShake();
            ProcessFOV();
            if (_lookingAt && _lookAtTarget) ProcessLookAt();
        }

        // ── Phase Hooks ───────────────────────────────────────────────────────

        void OnPhaseChanged(AbductionPhase phase)
        {
            switch (phase)
            {
                case AbductionPhase.AtmosphericEntry:
                    TriggerContinuousShake(0.08f, 10f);
                    break;
                case AbductionPhase.ActivateTractorBeam:
                    SetTargetFOV(tractorBeamFOV, 3f);
                    TriggerContinuousShake(0.03f, 12f);
                    break;
                case AbductionPhase.AbductHumans:
                    TriggerContinuousShake(0.05f, 18f);
                    break;
                case AbductionPhase.WarpDeparture:
                    SetTargetFOV(warpFOV, 1f);
                    ApplyShake(0.15f);
                    break;
                case AbductionPhase.Complete:
                    SetTargetFOV(baseFOV, 3f);
                    break;
            }
        }

        // ── Public API ────────────────────────────────────────────────────────

        public void ApplyShake(float intensity)
        {
            _currentShakeIntensity = Mathf.Max(_currentShakeIntensity, intensity);
        }

        public void TriggerContinuousShake(float intensity, float duration)
        {
            if (_shakeCoroutine != null) StopCoroutine(_shakeCoroutine);
            _shakeCoroutine = StartCoroutine(ContinuousShake(intensity, duration));
        }

        public void LookAtTarget(Transform target, float lerpSpeed)
        {
            _lookAtTarget = target;
            lookAtLerpSpeed = lerpSpeed;
            _lookingAt = true;
            enableAutoLookAt = true;
        }

        public void StopLookAt()
        {
            _lookingAt = false;
            enableAutoLookAt = false;
        }

        public void SetTargetFOV(float fov, float duration)
        {
            if (_fovCoroutine != null) StopCoroutine(_fovCoroutine);
            _fovCoroutine = StartCoroutine(LerpFOV(fov, duration));
        }

        // ── Processing ────────────────────────────────────────────────────────

        void ProcessShake()
        {
            if (_currentShakeIntensity <= 0.001f)
            {
                if (cameraRig) cameraRig.localPosition = Vector3.Lerp(cameraRig.localPosition, _originalRigPos, Time.deltaTime * 10f);
                return;
            }

            if (cameraRig)
            {
                Vector3 shakeOffset = new Vector3(
                    Random.Range(-1f, 1f) * _currentShakeIntensity,
                    Random.Range(-1f, 1f) * _currentShakeIntensity * 0.5f,
                    Random.Range(-1f, 1f) * _currentShakeIntensity * 0.1f
                );
                cameraRig.localPosition = _originalRigPos + shakeOffset;

                // Rotational shake
                Vector3 shakeRot = new Vector3(
                    Random.Range(-1f, 1f) * _currentShakeIntensity * shakeRotationalAmount,
                    Random.Range(-1f, 1f) * _currentShakeIntensity * shakeRotationalAmount * 0.5f,
                    0f
                );
                cameraRig.localRotation = _originalRigRot * Quaternion.Euler(shakeRot);
            }

            _currentShakeIntensity = Mathf.Lerp(_currentShakeIntensity, 0f, Time.deltaTime * shakeDecaySpeed);
        }

        void ProcessFOV()
        {
            if (!mainCamera) return;
            // Lerp is handled by LerpFOV coroutine
        }

        void ProcessLookAt()
        {
            if (!_lookAtTarget || !mainCamera) return;
            Vector3 dir = _lookAtTarget.position - mainCamera.transform.position;
            Quaternion target = Quaternion.LookRotation(dir);
            // Note: In VR, we don't override head rotation. Only nudge rig.
            if (GameManager.Instance?.currentMode == XRMode.Desktop)
                mainCamera.transform.rotation = Quaternion.Slerp(
                    mainCamera.transform.rotation, target,
                    Time.deltaTime * lookAtLerpSpeed);
        }

        // ── Coroutines ────────────────────────────────────────────────────────

        IEnumerator ContinuousShake(float intensity, float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float curve = shakeFalloff.Evaluate(t);
                _currentShakeIntensity = intensity * curve;
                yield return null;
            }
            _currentShakeIntensity = 0f;
        }

        IEnumerator LerpFOV(float targetFOV, float duration)
        {
            if (!mainCamera) yield break;
            float startFOV = mainCamera.fieldOfView;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                mainCamera.fieldOfView = Mathf.Lerp(startFOV, targetFOV, elapsed / duration);
                yield return null;
            }
            mainCamera.fieldOfView = targetFOV;
        }

        void OnDestroy()
        {
            GameManager.Instance?.OnPhaseChanged.RemoveListener(OnPhaseChanged);
        }
    }
}
