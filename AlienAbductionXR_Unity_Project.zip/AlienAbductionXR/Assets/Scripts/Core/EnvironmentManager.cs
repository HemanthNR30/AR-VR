using System.Collections;
using UnityEngine;
using UnityEngine.Rendering;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// EnvironmentManager
    /// Controls: skybox transitions, fog, day/night, ground effects,
    /// volumetric clouds, city lights, and scene layering.
    /// </summary>
    public class EnvironmentManager : MonoBehaviour
    {
        [Header("Scene Anchors")]
        public Transform earthCenter;
        public Transform houseTransform;
        public Transform groundPlane;

        [Header("Skyboxes")]
        public Material deepSpaceSkybox;
        public Material solarSystemSkybox;
        public Material dayAtmosphereSkybox;
        public Material nightSkybox;
        public Material stormySkybox;        // During abduction

        [Header("Celestial Objects")]
        public GameObject earthOrb;          // Low-poly Earth mesh for orbit view
        public GameObject moonOrb;
        public GameObject sunFlare;
        public GameObject[] starLayers;      // Parallax star planes

        [Header("Atmosphere")]
        public GameObject atmosphericEntryFirePlane; // Full-screen fire quad
        public ParticleSystem entryFireParticles;
        public ParticleSystem rainParticles;
        public ParticleSystem dustParticles;         // Kicked up by beam
        public GameObject[] cloudObjects;            // 3D cloud meshes
        public Light atmosphericRimLight;

        [Header("Ground Scene")]
        public GameObject groundSceneRoot;   // House, trees, road, humans
        public GameObject[] treeSilhouettes;
        public Renderer groundRenderer;
        public Light streetLamp1, streetLamp2;
        public Light[] windowLights;

        [Header("City Lights")]
        public GameObject cityLightsParent;  // Distant city glow planes

        [Header("Post FX")]
        public Volume globalVolume;

        [Header("Ground Shake")]
        public Transform cameraShakeTarget;

        // ── Private ───────────────────────────────────────────────────────────
        private float _groundShakeIntensity = 0f;
        private Coroutine _skyboxCoroutine;
        private bool _groundSceneVisible = false;

        // ── Unity ─────────────────────────────────────────────────────────────

        void Start()
        {
            // Begin in deep space
            RenderSettings.skybox = deepSpaceSkybox;
            RenderSettings.fogDensity = 0f;
            groundSceneRoot?.SetActive(false);
            earthOrb?.SetActive(false);
            atmosphericEntryFirePlane?.SetActive(false);
            cityLightsParent?.SetActive(false);
            dustParticles?.Stop();
        }

        void Update()
        {
            if (_groundShakeIntensity > 0f) ApplyGroundShake();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  SCENE TRANSITIONS
        // ══════════════════════════════════════════════════════════════════════

        public void ShowEarthOrbitView(bool show)
        {
            if (show)
            {
                earthOrb?.SetActive(true);
                moonOrb?.SetActive(true);
                StartCoroutine(LerpSkybox(solarSystemSkybox, 2f));
                StartCoroutine(RotateEarth());
            }
            else
            {
                StartCoroutine(FadeOutCelestials(2f));
            }
        }

        public void ShowAtmosphericEffects(bool show)
        {
            if (show)
            {
                atmosphericEntryFirePlane?.SetActive(true);
                entryFireParticles?.Play();
                RenderSettings.fogDensity = 0.02f;
                RenderSettings.fogColor = new Color(0.8f, 0.3f, 0.1f);
                StartCoroutine(FlickerAtmosphericRim());
            }
            else
            {
                atmosphericEntryFirePlane?.SetActive(false);
                entryFireParticles?.Stop();
                StartCoroutine(LerpFogDensity(0f, 3f));
            }
        }

        public void ShowGroundScene(bool show)
        {
            if (_groundSceneVisible == show) return;
            _groundSceneVisible = show;

            if (show)
            {
                groundSceneRoot?.SetActive(true);
                cityLightsParent?.SetActive(true);
                StartCoroutine(LerpSkybox(nightSkybox, 4f));
                StartCoroutine(FadeInGroundLights());
                StartCoroutine(LerpFog(new Color(0.04f, 0.08f, 0.15f), 0.005f, 3f));
                StartCoroutine(AnimateClouds());
            }
        }

        public void TriggerGroundShake(float intensity, float duration)
        {
            StartCoroutine(GroundShakeCoroutine(intensity, duration));
        }

        // ── Beam dust effect ──────────────────────────────────────────────────
        public void ActivateBeamDust(bool active)
        {
            if (active) dustParticles?.Play();
            else dustParticles?.Stop();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  COROUTINES
        // ══════════════════════════════════════════════════════════════════════

        IEnumerator LerpSkybox(Material target, float duration)
        {
            if (_skyboxCoroutine != null) StopCoroutine(_skyboxCoroutine);
            _skyboxCoroutine = StartCoroutine(DoLerpSkybox(target, duration));
            yield return _skyboxCoroutine;
        }

        IEnumerator DoLerpSkybox(Material target, float duration)
        {
            Material blendMat = new Material(RenderSettings.skybox);
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                // Unity skybox blend (requires _Blend property on skybox shader)
                RenderSettings.skybox = elapsed < duration * 0.5f
                    ? blendMat : target;
                DynamicGI.UpdateEnvironment();
                yield return null;
            }
            RenderSettings.skybox = target;
            DynamicGI.UpdateEnvironment();
        }

        IEnumerator LerpFogDensity(float target, float duration)
        {
            float start = RenderSettings.fogDensity;
            float elapsed = 0f;
            RenderSettings.fog = true;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                RenderSettings.fogDensity = Mathf.Lerp(start, target, elapsed / duration);
                yield return null;
            }
        }

        IEnumerator LerpFog(Color targetColor, float targetDensity, float duration)
        {
            RenderSettings.fog = true;
            float elapsed = 0f;
            Color startColor = RenderSettings.fogColor;
            float startDensity = RenderSettings.fogDensity;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                RenderSettings.fogColor = Color.Lerp(startColor, targetColor, t);
                RenderSettings.fogDensity = Mathf.Lerp(startDensity, targetDensity, t);
                yield return null;
            }
        }

        IEnumerator FadeInGroundLights()
        {
            yield return new WaitForSeconds(1f);
            float elapsed = 0f;
            while (elapsed < 3f)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / 3f;
                if (streetLamp1) streetLamp1.intensity = Mathf.Lerp(0f, 4f, t);
                if (streetLamp2) streetLamp2.intensity = Mathf.Lerp(0f, 4f, t);
                foreach (var wl in windowLights)
                    if (wl) wl.intensity = Mathf.Lerp(0f, 1.5f, t);
                yield return null;
            }
        }

        IEnumerator FadeOutCelestials(float duration)
        {
            yield return new WaitForSeconds(duration);
            earthOrb?.SetActive(false);
            moonOrb?.SetActive(false);
        }

        IEnumerator RotateEarth()
        {
            while (earthOrb && earthOrb.activeSelf)
            {
                earthOrb.transform.Rotate(Vector3.up, 3f * Time.deltaTime);
                yield return null;
            }
        }

        IEnumerator GroundShakeCoroutine(float intensity, float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                _groundShakeIntensity = intensity * Mathf.Sin(t * Mathf.PI);
                yield return null;
            }
            _groundShakeIntensity = 0f;
        }

        void ApplyGroundShake()
        {
            if (!cameraShakeTarget) return;
            Vector3 shake = new Vector3(
                Random.Range(-_groundShakeIntensity, _groundShakeIntensity) * 0.01f,
                Random.Range(-_groundShakeIntensity, _groundShakeIntensity) * 0.005f,
                0f
            );
            cameraShakeTarget.localPosition = Vector3.Lerp(
                cameraShakeTarget.localPosition, shake, 0.5f);
        }

        IEnumerator FlickerAtmosphericRim()
        {
            while (atmosphericEntryFirePlane && atmosphericEntryFirePlane.activeSelf)
            {
                if (atmosphericRimLight)
                    atmosphericRimLight.intensity = 2f + Random.Range(-0.5f, 0.5f);
                yield return new WaitForSeconds(0.05f);
            }
            if (atmosphericRimLight) atmosphericRimLight.intensity = 0f;
        }

        IEnumerator AnimateClouds()
        {
            while (true)
            {
                foreach (var cloud in cloudObjects)
                {
                    if (cloud) cloud.transform.Translate(Vector3.right * 0.05f * Time.deltaTime, Space.World);
                }
                yield return null;
            }
        }
    }
}
