using System.Collections;
using UnityEngine;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// SpaceshipController
    /// Handles ALL spaceship movement, FX, tractor beam, and lighting.
    /// Attach to your SpaceshipRoot prefab.
    /// </summary>
    public class SpaceshipController : MonoBehaviour
    {
        // ── Inspector References ───────────────────────────────────────────────

        [Header("Spaceship Mesh")]
        public Transform shipMesh;           // Root of the 3D model
        public Transform domeMesh;           // Glass dome on top
        public Transform[] enginePods;       // Bottom thruster pods

        [Header("Tractor Beam")]
        public Transform tractorBeamOrigin;  // Center bottom pivot
        public GameObject tractorBeamConeMesh;
        public Light tractorBeamLight;
        public ParticleSystem tractorBeamParticles;
        public ParticleSystem tractorBeamImpact; // Ground impact particles
        public ParticleSystem abductionSwirlFX;

        [Header("Engine FX")]
        public ParticleSystem[] engineThrusterFX;
        public ParticleSystem atmosphericEntryFireFX;
        public ParticleSystem warpStreak;
        public TrailRenderer warpTrail;

        [Header("Lights")]
        public Light[] runningLights;
        public Light bottomAmbientLight;
        public Light domeInteriorLight;

        [Header("Audio")]
        public AudioSource engineAudioSource;
        public AudioSource tractorBeamAudioSource;
        public AudioSource warpAudioSource;

        [Header("Settings")]
        public ExperienceSettings settings;

        // ── Public Properties ──────────────────────────────────────────────────
        public Vector3 TractorBeamOrigin => tractorBeamOrigin
            ? tractorBeamOrigin.position
            : transform.position + Vector3.down * 2f;

        // ── Private State ──────────────────────────────────────────────────────
        private Vector3 _hoverTargetPosition;
        private bool _hovering = false;
        private bool _tractorBeamActive = false;
        private float _noiseX, _noiseZ;
        private float _hoverAmp, _hoverFreq;
        private Coroutine _strobeCoroutine;
        private Coroutine _engineGlowCoroutine;

        // ── Unity ─────────────────────────────────────────────────────────────

        void Awake()
        {
            _noiseX = Random.Range(0f, 100f);
            _noiseZ = Random.Range(0f, 100f);
            tractorBeamConeMesh?.SetActive(false);
            if (tractorBeamLight) tractorBeamLight.enabled = false;
            if (bottomAmbientLight) bottomAmbientLight.intensity = 0f;
        }

        void Start()
        {
            _strobeCoroutine = StartCoroutine(StrobeRunningLights());
            _engineGlowCoroutine = StartCoroutine(AnimateEngineGlow());
        }

        void Update()
        {
            if (_hovering) ApplyHoverOscillation();
            if (_tractorBeamActive) AnimateTractorBeamLight();
            AnimateDomeRotation();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  MOVEMENT PHASES
        // ══════════════════════════════════════════════════════════════════════

        public void BeginApproachFromSpace(float startDistance, float duration)
        {
            StartCoroutine(ApproachCoroutine(startDistance, duration));
        }

        IEnumerator ApproachCoroutine(float startDist, float duration)
        {
            // Start far away in space (up + slightly to side)
            Vector3 spacePos = GameManager.Instance.environmentManager.earthCenter.position
                               + Vector3.up * startDist
                               + Vector3.right * startDist * 0.3f
                               + Vector3.forward * startDist * 0.2f;

            Vector3 atmospherePos = spacePos + (transform.position - spacePos).normalized * (startDist - 100f);

            transform.position = spacePos;
            transform.localScale = Vector3.one * 0.01f;

            foreach (var fx in engineThrusterFX) fx?.Play();

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float eased = EaseInCubic(t);

                transform.position = Vector3.Lerp(spacePos, atmospherePos, eased);
                transform.localScale = Vector3.Lerp(Vector3.one * 0.01f, Vector3.one, eased);
                engineAudioSource.pitch = Mathf.Lerp(0.3f, 1.2f, t);
                yield return null;
            }
        }

        public void BeginAtmosphericEntry(float duration)
        {
            StartCoroutine(AtmosphericEntryCoroutine(duration));
        }

        IEnumerator AtmosphericEntryCoroutine(float duration)
        {
            atmosphericEntryFireFX?.Play();

            Vector3 entryStart = transform.position;
            Vector3 entryEnd = entryStart + Vector3.down * 120f + Vector3.right * 20f;

            // Tilt ship for dramatic entry angle
            Quaternion startRot = transform.rotation;
            Quaternion entryRot = Quaternion.Euler(-25f, transform.eulerAngles.y, 5f);

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                transform.position = Vector3.Lerp(entryStart, entryEnd, EaseOutQuart(t));
                transform.rotation = Quaternion.Slerp(startRot, entryRot, Mathf.Clamp01(t * 2f));

                // Pulse fire intensity
                if (atmosphericEntryFireFX != null)
                {
                    var main = atmosphericEntryFireFX.main;
                    main.startSpeedMultiplier = Mathf.Lerp(3f, 8f, Mathf.Sin(t * Mathf.PI));
                }
                yield return null;
            }

            atmosphericEntryFireFX?.Stop();

            // Level out
            float levelElapsed = 0f;
            Quaternion currentRot = transform.rotation;
            while (levelElapsed < 2f)
            {
                levelElapsed += Time.deltaTime;
                transform.rotation = Quaternion.Slerp(currentRot, Quaternion.identity, levelElapsed / 2f);
                yield return null;
            }
        }

        public void BeginDescent(float hoverHeight, float duration)
        {
            StartCoroutine(DescentCoroutine(hoverHeight, duration));
        }

        IEnumerator DescentCoroutine(float hoverHeight, float duration)
        {
            Transform house = GameManager.Instance.environmentManager.houseTransform;
            _hoverTargetPosition = house.position + Vector3.up * hoverHeight;

            Vector3 descentStart = transform.position;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                transform.position = Vector3.Lerp(descentStart, _hoverTargetPosition, EaseOutExpo(t));
                engineAudioSource.pitch = Mathf.Lerp(1.2f, 0.7f, t);

                // Slowly illuminate the ground below
                if (bottomAmbientLight)
                    bottomAmbientLight.intensity = Mathf.Lerp(0f, 3f, t);

                yield return null;
            }

            transform.position = _hoverTargetPosition;
        }

        public void BeginHover(float amplitude, float frequency)
        {
            _hoverAmp = amplitude;
            _hoverFreq = frequency;
            _hovering = true;
            StartCoroutine(SlowRotationLoop());
        }

        void ApplyHoverOscillation()
        {
            float t = Time.time;
            float nx = (Mathf.PerlinNoise(t * _hoverFreq + _noiseX, 0f) - 0.5f) * _hoverAmp;
            float ny = Mathf.Sin(t * _hoverFreq * 1.3f) * _hoverAmp * 0.5f;
            float nz = (Mathf.PerlinNoise(0f, t * _hoverFreq + _noiseZ) - 0.5f) * _hoverAmp;
            transform.position = _hoverTargetPosition + new Vector3(nx, ny, nz);
        }

        IEnumerator SlowRotationLoop()
        {
            while (_hovering)
            {
                transform.Rotate(Vector3.up, settings.rotationSpeedHover * Time.deltaTime);
                yield return null;
            }
        }

        // ══════════════════════════════════════════════════════════════════════
        //  TRACTOR BEAM
        // ══════════════════════════════════════════════════════════════════════

        public void ActivateTractorBeam(float openDuration)
        {
            _tractorBeamActive = true;
            StartCoroutine(OpenTractorBeam(openDuration));
        }

        IEnumerator OpenTractorBeam(float duration)
        {
            tractorBeamConeMesh?.SetActive(true);
            tractorBeamParticles?.Play();
            tractorBeamImpact?.Play();

            if (tractorBeamLight) tractorBeamLight.enabled = true;
            if (tractorBeamAudioSource) tractorBeamAudioSource.Play();

            // Animate cone scale from 0
            Vector3 fullScale = tractorBeamConeMesh
                ? tractorBeamConeMesh.transform.localScale
                : Vector3.one;

            if (tractorBeamConeMesh)
                tractorBeamConeMesh.transform.localScale = Vector3.zero;

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                if (tractorBeamConeMesh)
                    tractorBeamConeMesh.transform.localScale = Vector3.Lerp(Vector3.zero, fullScale, EaseOutBack(t));

                if (tractorBeamLight)
                    tractorBeamLight.intensity = Mathf.Lerp(0f, settings.tractorBeamLightIntensity, t);

                if (bottomAmbientLight)
                    bottomAmbientLight.intensity = Mathf.Lerp(3f, 8f, t);

                yield return null;
            }

            abductionSwirlFX?.Play();
        }

        public void DeactivateTractorBeam(float closeDuration)
        {
            _tractorBeamActive = false;
            StartCoroutine(CloseTractorBeam(closeDuration));
        }

        IEnumerator CloseTractorBeam(float duration)
        {
            abductionSwirlFX?.Stop();
            tractorBeamParticles?.Stop();

            Vector3 startScale = tractorBeamConeMesh
                ? tractorBeamConeMesh.transform.localScale
                : Vector3.one;

            float startIntensity = tractorBeamLight ? tractorBeamLight.intensity : 0f;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;

                if (tractorBeamConeMesh)
                    tractorBeamConeMesh.transform.localScale = Vector3.Lerp(startScale, Vector3.zero, t);

                if (tractorBeamLight)
                    tractorBeamLight.intensity = Mathf.Lerp(startIntensity, 0f, t);

                yield return null;
            }

            tractorBeamConeMesh?.SetActive(false);
            if (tractorBeamLight) tractorBeamLight.enabled = false;
            tractorBeamImpact?.Stop();
            if (tractorBeamAudioSource) tractorBeamAudioSource.Stop();
        }

        void AnimateTractorBeamLight()
        {
            if (!tractorBeamLight) return;
            float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 6f);
            tractorBeamLight.intensity = Mathf.Lerp(
                settings.tractorBeamLightIntensity * 0.7f,
                settings.tractorBeamLightIntensity * 1.3f,
                pulse
            );
        }

        // ══════════════════════════════════════════════════════════════════════
        //  ASCENT & WARP
        // ══════════════════════════════════════════════════════════════════════

        public void BeginAscent(float duration)
        {
            _hovering = false;
            StartCoroutine(AscentCoroutine(duration));
        }

        IEnumerator AscentCoroutine(float duration)
        {
            atmosphericEntryFireFX?.Play();
            Vector3 start = transform.position;
            Vector3 end = start + Vector3.up * 200f;

            foreach (var fx in engineThrusterFX) fx?.Play();

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                transform.position = Vector3.Lerp(start, end, EaseInQuart(t));
                transform.localScale = Vector3.Lerp(Vector3.one, Vector3.one * 0.3f, EaseInQuart(t));
                engineAudioSource.pitch = Mathf.Lerp(0.7f, 1.5f, t);
                yield return null;
            }
        }

        public void BeginWarpDeparture(float duration)
        {
            StartCoroutine(WarpCoroutine(duration));
        }

        IEnumerator WarpCoroutine(float duration)
        {
            atmosphericEntryFireFX?.Stop();
            warpStreak?.Play();
            if (warpTrail) warpTrail.enabled = true;

            float elapsed = 0f;
            Vector3 start = transform.position;
            Vector3 warpDir = (transform.position - Camera.main.transform.position).normalized;
            Vector3 end = start + warpDir * 1000f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float eased = EaseInExpo(t);
                transform.position = Vector3.Lerp(start, end, eased);
                transform.localScale = Vector3.Lerp(Vector3.one * 0.3f, Vector3.zero, t);
                yield return null;
            }

            gameObject.SetActive(false);
        }

        // ══════════════════════════════════════════════════════════════════════
        //  AMBIENT FX
        // ══════════════════════════════════════════════════════════════════════

        IEnumerator StrobeRunningLights()
        {
            float timer = 0f;
            while (true)
            {
                timer += Time.deltaTime;
                // Strobe: flash pattern 0.08s on / 1.1s off
                bool on = (timer % 1.2f) < 0.08f;
                foreach (var l in runningLights)
                    if (l) l.intensity = on ? 6f : 0.8f;
                yield return null;
            }
        }

        IEnumerator AnimateEngineGlow()
        {
            while (true)
            {
                float glow = 0.7f + 0.3f * Mathf.Sin(Time.time * 8f);
                if (domeInteriorLight)
                    domeInteriorLight.intensity = glow * 2f;
                yield return null;
            }
        }

        void AnimateDomeRotation()
        {
            if (domeMesh)
                domeMesh.Rotate(Vector3.up, 8f * Time.deltaTime);
        }

        // ── Easing Library ─────────────────────────────────────────────────────
        static float EaseInCubic(float t) => t * t * t;
        static float EaseOutQuart(float t) => 1f - Mathf.Pow(1f - t, 4f);
        static float EaseOutExpo(float t) => t >= 1f ? 1f : 1f - Mathf.Pow(2f, -10f * t);
        static float EaseInQuart(float t) => t * t * t * t;
        static float EaseInExpo(float t) => t <= 0f ? 0f : Mathf.Pow(2f, 10f * t - 10f);
        static float EaseOutBack(float t)
        {
            const float c1 = 1.70158f, c3 = c1 + 1f;
            return 1f + c3 * Mathf.Pow(t - 1f, 3f) + c1 * Mathf.Pow(t - 1f, 2f);
        }
    }
}
