using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// HumanAbductionBehavior
    /// Full lifecycle: idle → panic → freeze → struggle → lift → abducted.
    /// Attach to each human NPC prefab.
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(Animator))]
    [RequireComponent(typeof(AudioSource))]
    public class HumanAbductionBehavior : MonoBehaviour
    {
        // ── Inspector ──────────────────────────────────────────────────────────

        [Header("Components")]
        public Animator animator;
        public NavMeshAgent navAgent;
        public Rigidbody rb;
        public new AudioSource audio;
        public SkinnedMeshRenderer meshRenderer;
        public Collider bodyCollider;

        [Header("FX")]
        public ParticleSystem tractorGlowFX;
        public ParticleSystem abductionSparksFX;
        public ParticleSystem disappearFX;
        public Light personalBeamLight;

        [Header("Audio Clips")]
        public AudioClip[] screamClips;
        public AudioClip struggleClip;
        public AudioClip floatClip;

        [Header("Materials")]
        public Material normalMaterial;
        public Material tractorGlowMaterial;   // Cyan emissive

        [Header("Settings")]
        public ExperienceSettings settings;

        // ── Animation Hashes ───────────────────────────────────────────────────
        static readonly int ANIM_PANIC     = Animator.StringToHash("IsPanicking");
        static readonly int ANIM_STRUGGLE  = Animator.StringToHash("IsStruggling");
        static readonly int ANIM_LIFTED    = Animator.StringToHash("IsLifted");
        static readonly int ANIM_IDLE      = Animator.StringToHash("IsIdle");
        static readonly int ANIM_FEAR      = Animator.StringToHash("FearBlend");

        // ── State ─────────────────────────────────────────────────────────────
        public enum HumanState { Idle, Panic, Freeze, Struggle, Lifted, Abducted }
        public HumanState State { get; private set; } = HumanState.Idle;

        private Vector3 _beamSource;
        private Vector3 _originalPosition;
        private bool _abductionStarted = false;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Awake()
        {
            _originalPosition = transform.position;
            if (personalBeamLight) personalBeamLight.intensity = 0f;
        }

        // ══════════════════════════════════════════════════════════════════════
        //  PUBLIC API
        // ══════════════════════════════════════════════════════════════════════

        public void TriggerPanic()
        {
            if (State != HumanState.Idle) return;
            State = HumanState.Panic;
            StartCoroutine(PanicBehavior());
        }

        public void BeginAbduction(Vector3 beamSourcePosition, float beamRadius)
        {
            if (_abductionStarted) return;
            _abductionStarted = true;
            _beamSource = beamSourcePosition;
            StartCoroutine(AbductionSequence());
        }

        // ══════════════════════════════════════════════════════════════════════
        //  BEHAVIOR COROUTINES
        // ══════════════════════════════════════════════════════════════════════

        IEnumerator PanicBehavior()
        {
            // Set panic animation
            animator.SetBool(ANIM_PANIC, true);
            animator.SetBool(ANIM_IDLE, false);

            navAgent.speed = settings.humanPanicSpeed;

            // Scream
            if (screamClips.Length > 0)
                audio.PlayOneShot(screamClips[Random.Range(0, screamClips.Length)], 0.9f);

            // Run in random direction away from ship
            float panicDuration = 4f;
            float elapsed = 0f;

            while (elapsed < panicDuration && State == HumanState.Panic)
            {
                elapsed += Time.deltaTime;

                // Recalculate panic direction periodically
                if (elapsed % 1.5f < Time.deltaTime)
                {
                    Vector3 awayFromShip = (transform.position - _beamSource).normalized;
                    awayFromShip.y = 0f;
                    Vector3 randomOffset = new Vector3(
                        Random.Range(-1f, 1f), 0f, Random.Range(-1f, 1f)
                    ).normalized * 0.4f;
                    Vector3 panicTarget = transform.position + (awayFromShip + randomOffset).normalized * 8f;
                    navAgent.SetDestination(panicTarget);
                }

                yield return null;
            }
        }

        IEnumerator AbductionSequence()
        {
            // ── STAGE 1: FREEZE ──────────────────────────────────────────
            State = HumanState.Freeze;
            navAgent.isStopped = true;
            navAgent.velocity = Vector3.zero;

            animator.SetBool(ANIM_PANIC, false);
            animator.SetFloat(ANIM_FEAR, 1f);

            // Second scream
            if (screamClips.Length > 0)
                audio.PlayOneShot(screamClips[Random.Range(0, screamClips.Length)], 1f);

            // Switch to glow material
            if (meshRenderer && tractorGlowMaterial)
                meshRenderer.material = tractorGlowMaterial;

            tractorGlowFX?.Play();

            if (personalBeamLight)
            {
                personalBeamLight.enabled = true;
                personalBeamLight.color = settings.tractorBeamColor;
            }

            yield return new WaitForSeconds(0.5f);

            // ── STAGE 2: STRUGGLE ────────────────────────────────────────
            State = HumanState.Struggle;
            animator.SetBool(ANIM_STRUGGLE, true);

            if (struggleClip) audio.PlayOneShot(struggleClip, 0.8f);

            // Vibrate/struggle
            float struggleTime = 1.5f;
            float elapsed = 0f;
            Vector3 basePos = transform.position;

            while (elapsed < struggleTime)
            {
                elapsed += Time.deltaTime;
                float intensity = Mathf.Sin(elapsed * 30f) * 0.04f;
                transform.position = basePos + new Vector3(intensity, 0, intensity * 0.5f);

                // Grow glow light
                if (personalBeamLight)
                    personalBeamLight.intensity = Mathf.Lerp(0f, 3f, elapsed / struggleTime);

                yield return null;
            }
            transform.position = basePos;

            // ── STAGE 3: LIFT OFF ────────────────────────────────────────
            State = HumanState.Lifted;
            animator.SetBool(ANIM_STRUGGLE, false);
            animator.SetBool(ANIM_LIFTED, true);

            navAgent.enabled = false;
            if (rb)
            {
                rb.isKinematic = false;
                rb.useGravity = false;
            }
            if (bodyCollider) bodyCollider.enabled = false;

            if (floatClip) audio.PlayOneShot(floatClip, 0.7f);
            abductionSparksFX?.Play();

            float liftDuration = 6f;
            elapsed = 0f;
            Vector3 liftStart = transform.position;
            Quaternion liftStartRot = transform.rotation;

            while (elapsed < liftDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / liftDuration;
                float eased = 1f - Mathf.Pow(1f - t, 2f);

                // Lift toward beam source
                transform.position = Vector3.Lerp(liftStart, _beamSource, eased);

                // Pull toward beam center horizontally
                Vector3 flatTarget = new Vector3(_beamSource.x, transform.position.y, _beamSource.z);
                transform.position = Vector3.Lerp(transform.position, flatTarget, t * 0.3f);

                // Spin
                transform.rotation = Quaternion.Slerp(liftStartRot,
                    liftStartRot * Quaternion.Euler(0f, settings.humanSpinSpeedLifted * liftDuration, 0f),
                    t);

                // Shrink as they near the ship
                float shrinkT = Mathf.Clamp01((t - 0.6f) / 0.4f);
                transform.localScale = Vector3.Lerp(Vector3.one, Vector3.zero, shrinkT);

                // Fade alpha via material emission
                if (tractorGlowMaterial)
                {
                    float fade = 1f - shrinkT;
                    tractorGlowMaterial.SetColor("_EmissionColor",
                        settings.tractorBeamColor * Mathf.Lerp(2f, 8f, Mathf.Sin(t * Mathf.PI)));
                }

                // Glow light intensity
                if (personalBeamLight)
                    personalBeamLight.intensity = Mathf.Lerp(3f, 0f, shrinkT);

                yield return null;
            }

            // ── STAGE 4: DISAPPEAR ───────────────────────────────────────
            State = HumanState.Abducted;
            abductionSparksFX?.Stop();
            disappearFX?.Play();
            tractorGlowFX?.Stop();

            yield return new WaitForSeconds(0.3f);
            gameObject.SetActive(false);

            Debug.Log($"[AbductionXR] {gameObject.name} successfully abducted.");
        }
    }
}
