using System.Collections;
using UnityEngine;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// AudioManager
    /// Manages all spatial audio, music layers, SFX, and audio mixing.
    /// Uses a layered approach for cinematic sound design.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        [Header("Audio Sources")]
        public AudioSource ambientSource;        // Looping ambient
        public AudioSource engineSource;         // Spaceship engine
        public AudioSource tractorBeamSource;    // Tractor beam hum
        public AudioSource abductionSource;      // Abduction ambience
        public AudioSource musicSource;          // Background score
        public AudioSource sfxSource;            // One-shot SFX

        [Header("Ambient Clips")]
        public AudioClip nightAmbience;          // Crickets, wind
        public AudioClip deepSpaceAmbience;      // Silent hiss
        public AudioClip tensionDrone;           // Before abduction

        [Header("Engine Clips")]
        public AudioClip engineApproachLoop;
        public AudioClip engineHoverLoop;
        public AudioClip engineDescentLoop;
        public AudioClip engineAscentLoop;

        [Header("SFX Clips")]
        public AudioClip atmosphericEntryBoom;
        public AudioClip tractorBeamActivate;
        public AudioClip tractorBeamLoop;
        public AudioClip abductionSwoosh;
        public AudioClip warpCharge;
        public AudioClip warpJump;
        public AudioClip groundRumble;
        public AudioClip electricHum;

        [Header("Music Clips")]
        public AudioClip spaceApproachMusic;     // Eerie ambient score
        public AudioClip tensionBuildMusic;      // Building dread
        public AudioClip abductionClimax;        // Peak moment
        public AudioClip departureMusic;         // Ship leaving

        [Header("Settings")]
        public ExperienceSettings settings;

        private Coroutine _enginePitchCoroutine;
        private float _currentEnginePitch = 0.5f;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Awake()
        {
            SetMasterVolume(settings.masterVolume);
        }

        void SetMasterVolume(float v)
        {
            AudioListener.volume = v;
        }

        // ══════════════════════════════════════════════════════════════════════
        //  PUBLIC API
        // ══════════════════════════════════════════════════════════════════════

        public void PlayAmbient()
        {
            if (deepSpaceAmbience)
            {
                ambientSource.clip = deepSpaceAmbience;
                ambientSource.loop = true;
                ambientSource.volume = settings.ambienceVolume * 0.5f;
                ambientSource.Play();
            }
        }

        public void PlayEngineApproach()
        {
            CrossfadeEngine(engineApproachLoop, 0.6f, 2f);
            PlayMusic(spaceApproachMusic, 0.3f);
        }

        public void PlayAtmosphericEntry()
        {
            sfxSource.PlayOneShot(atmosphericEntryBoom, settings.sfxVolume);
            CrossfadeAmbient(tensionDrone, settings.ambienceVolume, 2f);
        }

        public void PlayDescentHum()
        {
            CrossfadeEngine(engineDescentLoop, 0.7f, 3f);
            CrossfadeAmbient(nightAmbience, settings.ambienceVolume, 4f);
            PlayMusic(tensionBuildMusic, 0.5f);
        }

        public void PlayHoverHum()
        {
            CrossfadeEngine(engineHoverLoop, 0.5f, 2f);
        }

        public void PlayTractorBeamActivation()
        {
            sfxSource.PlayOneShot(tractorBeamActivate, settings.sfxVolume);
            tractorBeamSource.clip = tractorBeamLoop;
            tractorBeamSource.loop = true;
            tractorBeamSource.volume = 0f;
            tractorBeamSource.Play();
            StartCoroutine(FadeVolume(tractorBeamSource, 0f, 0.7f, 2f));
        }

        public void PlayAbductionAmbience()
        {
            PlayMusic(abductionClimax, 0.7f);
            sfxSource.PlayOneShot(abductionSwoosh, settings.sfxVolume);
            PlayLoopingSFX(electricHum, 0.4f);
        }

        public void PlayAscent()
        {
            CrossfadeEngine(engineAscentLoop, 0.9f, 2f);
            StartCoroutine(FadeVolume(tractorBeamSource, tractorBeamSource.volume, 0f, 3f));
            PlayMusic(departureMusic, 0.6f);
        }

        public void PlayWarpSound()
        {
            sfxSource.PlayOneShot(warpCharge, settings.sfxVolume * 0.8f);
            StartCoroutine(DelayedOneShot(warpJump, 1.5f, settings.sfxVolume));
        }

        public void SetEnginePitch(float pitch)
        {
            engineSource.pitch = pitch;
            _currentEnginePitch = pitch;
        }

        // ══════════════════════════════════════════════════════════════════════
        //  HELPERS
        // ══════════════════════════════════════════════════════════════════════

        void CrossfadeEngine(AudioClip newClip, float targetVolume, float fadeDuration)
        {
            if (!newClip) return;
            StartCoroutine(CrossfadeSource(engineSource, newClip, targetVolume, fadeDuration));
        }

        void CrossfadeAmbient(AudioClip newClip, float targetVolume, float fadeDuration)
        {
            if (!newClip) return;
            StartCoroutine(CrossfadeSource(ambientSource, newClip, targetVolume, fadeDuration));
        }

        void PlayMusic(AudioClip clip, float targetVolume)
        {
            if (!clip) return;
            StartCoroutine(CrossfadeSource(musicSource, clip, targetVolume, 3f));
        }

        void PlayLoopingSFX(AudioClip clip, float volume)
        {
            if (!abductionSource || !clip) return;
            abductionSource.clip = clip;
            abductionSource.loop = true;
            abductionSource.volume = volume;
            abductionSource.Play();
        }

        IEnumerator CrossfadeSource(AudioSource source, AudioClip newClip, float targetVol, float duration)
        {
            if (!source) yield break;

            float startVol = source.volume;
            float halfDur = duration * 0.5f;

            // Fade out
            float elapsed = 0f;
            while (elapsed < halfDur)
            {
                elapsed += Time.deltaTime;
                source.volume = Mathf.Lerp(startVol, 0f, elapsed / halfDur);
                yield return null;
            }

            source.clip = newClip;
            source.loop = true;
            source.Play();

            // Fade in
            elapsed = 0f;
            while (elapsed < halfDur)
            {
                elapsed += Time.deltaTime;
                source.volume = Mathf.Lerp(0f, targetVol * settings.sfxVolume, elapsed / halfDur);
                yield return null;
            }
            source.volume = targetVol * settings.sfxVolume;
        }

        IEnumerator FadeVolume(AudioSource source, float from, float to, float duration)
        {
            if (!source) yield break;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                source.volume = Mathf.Lerp(from, to, elapsed / duration);
                yield return null;
            }
            source.volume = to;
            if (to <= 0f) source.Stop();
        }

        IEnumerator DelayedOneShot(AudioClip clip, float delay, float volume)
        {
            yield return new WaitForSeconds(delay);
            if (clip) sfxSource.PlayOneShot(clip, volume);
        }
    }
}
