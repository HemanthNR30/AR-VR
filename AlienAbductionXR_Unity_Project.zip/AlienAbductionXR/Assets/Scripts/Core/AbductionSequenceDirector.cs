using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// AbductionSequenceDirector
    /// Orchestrates the full 2-minute cinematic sequence across 10 phases.
    /// Think of this as the "director" calling action on every scene element.
    /// </summary>
    public class AbductionSequenceDirector : MonoBehaviour
    {
        [Header("Scene References")]
        public SpaceshipController spaceship;
        public EnvironmentManager environment;
        public PostProcessingController postFX;
        public AudioManager audioManager;
        public CinematicCameraController cinematicCamera;
        public List<HumanAbductionBehavior> humans = new List<HumanAbductionBehavior>();
        public HUDController hud;

        [Header("Settings")]
        public ExperienceSettings settings;

        private ExperienceSettings S => settings;
        private bool _running = false;

        // ── Entry Point ────────────────────────────────────────────────────────

        public void BeginSequence()
        {
            if (_running) return;
            _running = true;
            StartCoroutine(MasterSequence());
        }

        // ── MASTER SEQUENCE ────────────────────────────────────────────────────

        IEnumerator MasterSequence()
        {
            // ══════════════════════════════════════════════════
            // PHASE 1 ─ DEEP SPACE APPROACH (12s)
            // Ship tiny dot of light approaching from deep space
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.ApproachFromSpace, () => StartCoroutine(Phase_ApproachFromSpace()));

            // ══════════════════════════════════════════════════
            // PHASE 2 ─ SOLAR SYSTEM TRANSIT (8s)
            // Ship passes the moon, Earth visible ahead
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.AtmosphericEntry, () => StartCoroutine(Phase_SolarTransit()));

            // ══════════════════════════════════════════════════
            // PHASE 3 ─ EARTH ORBIT (10s)
            // Ship orbits earth, scouts location
            // ══════════════════════════════════════════════════
            environment.ShowEarthOrbitView(true);
            yield return new WaitForSeconds(10f);
            environment.ShowEarthOrbitView(false);

            // ══════════════════════════════════════════════════
            // PHASE 4 ─ ATMOSPHERIC ENTRY (10s)
            // Fiery descent, camera shake, heat distortion
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.AtmosphericEntry, () => StartCoroutine(Phase_AtmosphericEntry()));

            // ══════════════════════════════════════════════════
            // PHASE 5 ─ DESCENT TO HOUSE (10s)
            // Ship descends slowly over neighbourhood
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.Descend, () => StartCoroutine(Phase_Descend()));

            // ══════════════════════════════════════════════════
            // PHASE 6 ─ TARGET ACQUISITION / HOVER (8s)
            // Ship locks on, humans start panicking
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.Hover, () => StartCoroutine(Phase_Hover()));

            // ══════════════════════════════════════════════════
            // PHASE 7 ─ TRACTOR BEAM ACTIVATION (6s)
            // Beam opens, blue light floods scene
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.ActivateTractorBeam, () => StartCoroutine(Phase_BeamActivate()));

            // ══════════════════════════════════════════════════
            // PHASE 8 ─ ABDUCTION IN PROGRESS (18s)
            // Humans lifted one by one, spiral up into ship
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.AbductHumans, () => StartCoroutine(Phase_Abduct()));

            // ══════════════════════════════════════════════════
            // PHASE 9 ─ ASCENT (10s)
            // Ship climbs away with humans inside
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.Ascend, () => StartCoroutine(Phase_Ascend()));

            // ══════════════════════════════════════════════════
            // PHASE 10 ─ WARP DEPARTURE (5s)
            // Ship streaks to space, warp FX, scene ends
            // ══════════════════════════════════════════════════
            yield return RunPhase(AbductionPhase.WarpDeparture, () => StartCoroutine(Phase_WarpDeparture()));

            GameManager.Instance.SetPhase(AbductionPhase.Complete);
            hud?.ShowMissionComplete();
        }

        // ── PHASE RUNNER ──────────────────────────────────────────────────────

        IEnumerator RunPhase(AbductionPhase phase, System.Func<Coroutine> phaseCoroutine)
        {
            GameManager.Instance.SetPhase(phase);
            hud?.AnnouncePhase(phase);
            yield return phaseCoroutine();
        }

        // ══════════════════════════════════════════════════════════════════════
        //  PHASE IMPLEMENTATIONS
        // ══════════════════════════════════════════════════════════════════════

        IEnumerator Phase_ApproachFromSpace()
        {
            audioManager.PlayEngineApproach();
            spaceship.BeginApproachFromSpace(S.spaceApproachStartDistance, S.approachDuration);
            postFX.SetSpaceMode();

            float elapsed = 0f;
            while (elapsed < S.approachDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / S.approachDuration;
                audioManager.SetEnginePitch(Mathf.Lerp(0.4f, 1.1f, t));
                hud?.UpdateTelemetry(
                    altitude: Mathf.Lerp(600f, 80f, t),
                    velocity: Mathf.Lerp(0f, 8000f, t),
                    temperature: Mathf.Lerp(-270f, -180f, t)
                );
                yield return null;
            }
        }

        IEnumerator Phase_SolarTransit()
        {
            float elapsed = 0f;
            while (elapsed < 8f) { elapsed += Time.deltaTime; yield return null; }
        }

        IEnumerator Phase_AtmosphericEntry()
        {
            audioManager.PlayAtmosphericEntry();
            spaceship.BeginAtmosphericEntry(S.atmosphericEntryDuration);
            postFX.TriggerAtmosphericEntry(true);
            environment.ShowAtmosphericEffects(true);

            float elapsed = 0f;
            while (elapsed < S.atmosphericEntryDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / S.atmosphericEntryDuration;
                float shakeIntensity = Mathf.Sin(t * Mathf.PI) * S.cameraShakeIntensityEntry;
                cinematicCamera.ApplyShake(shakeIntensity);
                hud?.UpdateTelemetry(
                    altitude: Mathf.Lerp(80f, 15f, t),
                    velocity: Mathf.Lerp(8000f, 800f, t),
                    temperature: Mathf.Lerp(-180f, 1200f, t)
                );
                yield return null;
            }

            postFX.TriggerAtmosphericEntry(false);
            environment.ShowAtmosphericEffects(false);
        }

        IEnumerator Phase_Descend()
        {
            audioManager.PlayDescentHum();
            spaceship.BeginDescent(S.hoverHeight, S.descentDuration);
            environment.ShowGroundScene(true);

            float elapsed = 0f;
            while (elapsed < S.descentDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / S.descentDuration;
                hud?.UpdateTelemetry(
                    altitude: Mathf.Lerp(15f, 0.8f, t),
                    velocity: Mathf.Lerp(800f, 60f, t),
                    temperature: Mathf.Lerp(-80f, -40f, t)
                );
                yield return null;
            }
        }

        IEnumerator Phase_Hover()
        {
            spaceship.BeginHover(S.hoverOscillationAmplitude, S.hoverOscillationFrequency);
            audioManager.PlayHoverHum();

            // After 3s, trigger human panic
            yield return new WaitForSeconds(3f);
            foreach (var h in humans) h.TriggerPanic();

            yield return new WaitForSeconds(S.hoverDuration - 3f);
        }

        IEnumerator Phase_BeamActivate()
        {
            audioManager.PlayTractorBeamActivation();
            spaceship.ActivateTractorBeam(S.beamActivationDuration);
            postFX.TriggerTractorBeam(true);
            environment.TriggerGroundShake(1.5f, 6f);
            cinematicCamera.LookAtTarget(spaceship.transform, 2f);

            float elapsed = 0f;
            while (elapsed < S.beamActivationDuration)
            {
                elapsed += Time.deltaTime;
                cinematicCamera.ApplyShake(S.cameraShakeIntensityBeam);
                hud?.SetBeamStatus(elapsed / S.beamActivationDuration);
                yield return null;
            }
        }

        IEnumerator Phase_Abduct()
        {
            audioManager.PlayAbductionAmbience();

            for (int i = 0; i < humans.Count; i++)
            {
                humans[i].BeginAbduction(spaceship.TractorBeamOrigin, S.tractorBeamRadius);
                yield return new WaitForSeconds(S.humanAbductionStagger);
            }

            // Wait for last human to finish
            float remaining = S.abductionDuration - (humans.Count * S.humanAbductionStagger);
            yield return new WaitForSeconds(Mathf.Max(remaining, 4f));
        }

        IEnumerator Phase_Ascend()
        {
            spaceship.BeginAscent(S.ascendDuration);
            spaceship.DeactivateTractorBeam(2f);
            postFX.TriggerTractorBeam(false);
            audioManager.PlayAscent();
            environment.TriggerGroundShake(0.5f, 3f);

            float elapsed = 0f;
            while (elapsed < S.ascendDuration)
            {
                elapsed += Time.deltaTime;
                hud?.UpdateTelemetry(
                    altitude: Mathf.Lerp(0.8f, 120f, elapsed / S.ascendDuration),
                    velocity: Mathf.Lerp(60f, 5000f, elapsed / S.ascendDuration),
                    temperature: Mathf.Lerp(-40f, -270f, elapsed / S.ascendDuration)
                );
                yield return null;
            }
        }

        IEnumerator Phase_WarpDeparture()
        {
            spaceship.BeginWarpDeparture(S.warpDuration);
            postFX.TriggerWarpFX();
            audioManager.PlayWarpSound();
            cinematicCamera.ApplyShake(0.15f);
            yield return new WaitForSeconds(S.warpDuration);
        }
    }
}
