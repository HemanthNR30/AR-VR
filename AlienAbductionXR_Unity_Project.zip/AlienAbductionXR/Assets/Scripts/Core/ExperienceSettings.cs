using UnityEngine;

namespace AlienAbductionXR.Core
{
    /// <summary>
    /// ScriptableObject holding all tunable experience parameters.
    /// Create via: Assets > Create > AlienAbductionXR > ExperienceSettings
    /// </summary>
    [CreateAssetMenu(menuName = "AlienAbductionXR/ExperienceSettings", fileName = "ExperienceSettings")]
    public class ExperienceSettings : ScriptableObject
    {
        [Header("Timing")]
        public float introPauseSeconds = 2f;
        public float approachDuration = 12f;
        public float atmosphericEntryDuration = 8f;
        public float descentDuration = 10f;
        public float hoverDuration = 6f;
        public float beamActivationDuration = 5f;
        public float abductionDuration = 18f;
        public float ascendDuration = 10f;
        public float warpDuration = 5f;
        public float humanAbductionStagger = 2.5f;

        [Header("Spaceship Movement")]
        public float spaceApproachStartDistance = 600f;
        public float hoverHeight = 18f;
        public float hoverOscillationAmplitude = 0.3f;
        public float hoverOscillationFrequency = 0.4f;
        public float rotationSpeedHover = 4f;

        [Header("Tractor Beam")]
        public float tractorBeamRadius = 4f;
        public float tractorBeamLightIntensity = 10f;
        public Color tractorBeamColor = new Color(0.2f, 0.9f, 1f, 1f);

        [Header("Human Abduction")]
        public float humanLiftSpeed = 3f;
        public float humanPanicSpeed = 4.5f;
        public float humanSpinSpeedLifted = 120f;

        [Header("Camera")]
        public float cameraShakeIntensityEntry = 0.08f;
        public float cameraShakeIntensityBeam = 0.04f;
        public float cameraShakeIntensityAbduction = 0.12f;

        [Header("Post Processing")]
        public float bloomIntensityNormal = 1f;
        public float bloomIntensityBeam = 6f;
        public float bloomIntensityEntry = 3f;
        public float vignetteIntensityBase = 0.3f;
        public float vignetteIntensityMax = 0.7f;

        [Header("AR Settings")]
        public float arTableTopScale = 0.05f;
        public float arRoomScale = 0.3f;

        [Header("Audio")]
        [Range(0f,1f)] public float masterVolume = 1f;
        [Range(0f,1f)] public float sfxVolume = 1f;
        [Range(0f,1f)] public float ambienceVolume = 0.6f;
    }
}
