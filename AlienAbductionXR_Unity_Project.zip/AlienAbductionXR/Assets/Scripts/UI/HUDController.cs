using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.UI
{
    /// <summary>
    /// HUDController
    /// Manages the cinematic AR/VR HUD:
    /// - Live telemetry readouts
    /// - Phase announcement banners
    /// - Mission timeline
    /// - Tractor beam status
    /// - Mission complete screen
    /// </summary>
    public class HUDController : MonoBehaviour
    {
        [Header("Main HUD")]
        public CanvasGroup hudGroup;
        public TextMeshProUGUI phaseText;
        public TextMeshProUGUI statusText;

        [Header("Telemetry")]
        public TextMeshProUGUI altitudeText;
        public TextMeshProUGUI velocityText;
        public TextMeshProUGUI temperatureText;
        public TextMeshProUGUI beamStatusText;
        public TextMeshProUGUI lockStatusText;
        public TextMeshProUGUI modeText;
        public TextMeshProUGUI fpsText;

        [Header("Timeline")]
        public Slider timelineSlider;
        public TextMeshProUGUI timelineTimeText;
        public CanvasGroup timelineGroup;

        [Header("Phase Announcement")]
        public CanvasGroup phaseAnnounceBanner;
        public TextMeshProUGUI phaseAnnounceNumber;
        public TextMeshProUGUI phaseAnnounceTitle;
        public Animator phaseAnnounceAnimator;

        [Header("Beam Status Bar")]
        public Slider beamChargeSlider;
        public Image beamChargeBar;
        public Gradient beamChargeGradient;

        [Header("Alert")]
        public CanvasGroup alertGroup;
        public TextMeshProUGUI alertText;
        public Image alertBG;

        [Header("Mission Complete")]
        public CanvasGroup missionCompleteGroup;
        public TextMeshProUGUI missionCompleteTitle;
        public TextMeshProUGUI missionCompleteStats;

        [Header("Corner Brackets")]
        public RectTransform[] cornerBrackets; // Animated HUD corners

        // ── Private ───────────────────────────────────────────────────────────
        private float _totalDuration = 120f;
        private float _elapsedTime = 0f;
        private int _fps = 0;
        private int _fpsCount = 0;
        private float _fpsTimer = 0f;
        private bool _counting = false;

        // ── Phase Names ───────────────────────────────────────────────────────
        static readonly string[] PhaseNames = {
            "DEEP SPACE APPROACH",
            "ATMOSPHERIC ENTRY",
            "EARTH ORBIT TRANSIT",
            "ATMOSPHERIC DESCENT",
            "HOVER — TARGET LOCK",
            "TRACTOR BEAM ACTIVE",
            "ABDUCTION IN PROGRESS",
            "ASCENDING TO ORBIT",
            "WARP DEPARTURE",
            "MISSION COMPLETE"
        };

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Start()
        {
            hudGroup.alpha = 0f;
            alertGroup.alpha = 0f;
            missionCompleteGroup.alpha = 0f;
            phaseAnnounceBanner.alpha = 0f;
            beamChargeSlider.value = 0f;

            // Mode badge
            if (modeText)
                modeText.text = GameManager.Instance?.currentMode.ToString().ToUpper() + " MODE";

            StartCoroutine(FadeInHUD(1.5f));
            StartCoroutine(FPSCounter());
            StartCoroutine(AnimateCornerBrackets());
        }

        void Update()
        {
            if (!_counting) return;
            _elapsedTime += Time.deltaTime;

            // Timeline
            if (timelineSlider)
                timelineSlider.value = Mathf.Clamp01(_elapsedTime / _totalDuration);

            if (timelineTimeText)
            {
                int m = Mathf.FloorToInt(_elapsedTime / 60f);
                int s = Mathf.FloorToInt(_elapsedTime % 60f);
                int tm = Mathf.FloorToInt(_totalDuration / 60f);
                int ts = Mathf.FloorToInt(_totalDuration % 60f);
                timelineTimeText.text = $"{m:00}:{s:00} / {tm:00}:{ts:00}";
            }

            if (fpsText) fpsText.text = $"FPS: {_fps}";
        }

        // ── Public API ────────────────────────────────────────────────────────

        public void AnnouncePhase(AbductionPhase phase)
        {
            int idx = (int)phase;
            if (idx >= PhaseNames.Length) return;

            string phaseName = PhaseNames[idx];
            if (phaseText) phaseText.text = phaseName;
            if (!_counting) _counting = true;

            StartCoroutine(ShowPhaseAnnouncement(idx + 1, phaseName));
        }

        public void UpdateTelemetry(float altitude, float velocity, float temperature)
        {
            if (altitudeText)
                altitudeText.text = $"ALT:  {altitude:F1} KM";
            if (velocityText)
                velocityText.text = $"VEL:  {velocity:F0} M/S";
            if (temperatureText)
            {
                temperatureText.text = $"TEMP: {temperature:F0}°C";
                temperatureText.color = temperature > 500f
                    ? new Color(1f, 0.4f, 0.1f)
                    : temperature > 0f
                        ? Color.yellow
                        : Color.cyan;
            }
        }

        public void SetBeamStatus(float chargeProgress)
        {
            if (beamChargeSlider) beamChargeSlider.value = chargeProgress;
            if (beamChargeBar) beamChargeBar.color = beamChargeGradient.Evaluate(chargeProgress);
            if (beamStatusText)
                beamStatusText.text = chargeProgress < 1f
                    ? $"BEAM: CHARGING {chargeProgress * 100f:F0}%"
                    : "BEAM: ██████ ACTIVE";
        }

        public void ShowAlert(string message, float duration = 3f)
        {
            StartCoroutine(AlertPulse(message, duration));
        }

        public void ShowMissionComplete()
        {
            StartCoroutine(MissionCompleteReveal());
        }

        // ── Coroutines ────────────────────────────────────────────────────────

        IEnumerator FadeInHUD(float delay)
        {
            yield return new WaitForSeconds(delay);
            float elapsed = 0f;
            while (elapsed < 1f)
            {
                elapsed += Time.deltaTime;
                hudGroup.alpha = elapsed;
                yield return null;
            }
            hudGroup.alpha = 1f;
        }

        IEnumerator ShowPhaseAnnouncement(int number, string title)
        {
            if (!phaseAnnounceBanner) yield break;

            if (phaseAnnounceNumber) phaseAnnounceNumber.text = $"PHASE {number:00}";
            if (phaseAnnounceTitle) phaseAnnounceTitle.text = title;

            // Fade in
            float elapsed = 0f;
            while (elapsed < 0.3f)
            {
                elapsed += Time.deltaTime;
                phaseAnnounceBanner.alpha = elapsed / 0.3f;
                yield return null;
            }

            yield return new WaitForSeconds(2.5f);

            // Fade out
            elapsed = 0f;
            while (elapsed < 0.5f)
            {
                elapsed += Time.deltaTime;
                phaseAnnounceBanner.alpha = 1f - elapsed / 0.5f;
                yield return null;
            }
            phaseAnnounceBanner.alpha = 0f;
        }

        IEnumerator AlertPulse(string message, float duration)
        {
            if (alertText) alertText.text = message;

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float pulse = Mathf.Abs(Mathf.Sin(elapsed * 4f));
                alertGroup.alpha = pulse;
                yield return null;
            }
            alertGroup.alpha = 0f;
        }

        IEnumerator MissionCompleteReveal()
        {
            yield return new WaitForSeconds(1f);

            if (missionCompleteTitle) missionCompleteTitle.text = "ABDUCTION COMPLETE";
            if (missionCompleteStats)
                missionCompleteStats.text = "3 HUMANS ACQUIRED\nMISSION SUCCESS\n\nRETURNING TO ORBIT";

            float elapsed = 0f;
            while (elapsed < 2f)
            {
                elapsed += Time.deltaTime;
                missionCompleteGroup.alpha = elapsed / 2f;
                yield return null;
            }
        }

        IEnumerator FPSCounter()
        {
            while (true)
            {
                _fpsCount++;
                yield return new WaitForSeconds(0.016f);
                _fpsTimer += 0.016f;
                if (_fpsTimer >= 1f) { _fps = _fpsCount; _fpsCount = 0; _fpsTimer = 0f; }
            }
        }

        IEnumerator AnimateCornerBrackets()
        {
            // Subtle pulsing brackets
            while (true)
            {
                float pulse = 0.7f + 0.3f * Mathf.Sin(Time.time * 1.5f);
                foreach (var b in cornerBrackets)
                    if (b) b.localScale = Vector3.one * pulse;
                yield return null;
            }
        }
    }
}
