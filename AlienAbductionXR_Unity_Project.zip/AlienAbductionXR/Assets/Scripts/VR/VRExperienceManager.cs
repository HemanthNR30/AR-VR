using System.Collections;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;
using TMPro;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.VR
{
    /// <summary>
    /// VRExperienceManager
    /// Full VR setup: locomotion, haptics, VR UI, comfort settings,
    /// skybox transitions, and immersive triggers.
    /// Supports: Meta Quest 2/3, PC VR via OpenXR, Pico.
    /// </summary>
    public class VRExperienceManager : MonoBehaviour
    {
        [Header("XR Rig")]
        public XROrigin xrOrigin;
        public ActionBasedController leftController;
        public ActionBasedController rightController;
        public Camera vrCamera;

        [Header("Scene Position")]
        public Transform playerStartPoint;   // Where player stands (yard, facing house)
        public Transform lookTarget;         // Auto-face toward house on start

        [Header("Comfort")]
        public bool enableVignetteOnMove = true;
        public bool enableTeleportLocomotion = true;
        public TeleportationProvider teleportProvider;
        public float moveComfortVignette = 0.5f;

        [Header("Hand Controllers")]
        public GameObject leftHandModel;
        public GameObject rightHandModel;
        public LineRenderer leftAimLine;
        public LineRenderer rightAimLine;

        [Header("VR HUD")]
        public Canvas vrHUDCanvas;          // World-space canvas, attached to camera
        public TextMeshProUGUI vrPhaseText;
        public TextMeshProUGUI vrTelemetryText;

        [Header("Haptic Settings")]
        public float beamHapticIntensity = 0.6f;
        public float abductionHapticIntensity = 1.0f;
        public float groundRumbleHapticIntensity = 0.3f;

        [Header("Cinematic Triggers")]
        public bool autoLookAtSpaceship = true;
        public float autoLookLerpSpeed = 0.5f;

        // ── Private ───────────────────────────────────────────────────────────
        private bool _hapticBeamActive = false;
        private InputDevice _leftDevice, _rightDevice;
        private Coroutine _hapticCoroutine;
        private Vector3 _originalCameraLocalPos;

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Start()
        {
            _originalCameraLocalPos = vrCamera.transform.localPosition;
            PositionPlayer();
            GetControllerDevices();
            SubscribeToPhaseEvents();

            // Start VR after brief fade-in
            StartCoroutine(VRIntroSequence());
        }

        void Update()
        {
            if (autoLookAtSpaceship && GameManager.Instance?.spaceshipController != null)
                UpdateAutoLook();
        }

        // ── Setup ─────────────────────────────────────────────────────────────

        void PositionPlayer()
        {
            if (xrOrigin && playerStartPoint)
                xrOrigin.transform.position = playerStartPoint.position;

            if (lookTarget && vrCamera)
            {
                Vector3 dir = lookTarget.position - vrCamera.transform.position;
                dir.y = 0f;
                xrOrigin.transform.rotation = Quaternion.LookRotation(dir);
            }
        }

        void GetControllerDevices()
        {
            _leftDevice = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
            _rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
        }

        void SubscribeToPhaseEvents()
        {
            GameManager.Instance?.OnPhaseChanged.AddListener(OnPhaseChanged);
        }

        // ── Phase Reactions ───────────────────────────────────────────────────

        void OnPhaseChanged(AbductionPhase phase)
        {
            StopHaptics();

            switch (phase)
            {
                case AbductionPhase.AtmosphericEntry:
                    StartCoroutine(GroundRumbleHaptics(8f));
                    UpdateVRHUD("ATMOSPHERIC ENTRY", "BRACE FOR IMPACT");
                    break;

                case AbductionPhase.Descend:
                    StartCoroutine(GroundRumbleHaptics(10f));
                    break;

                case AbductionPhase.Hover:
                    UpdateVRHUD("HOVERING — LOCK ON", "UNKNOWN CRAFT DETECTED");
                    break;

                case AbductionPhase.ActivateTractorBeam:
                    _hapticBeamActive = true;
                    _hapticCoroutine = StartCoroutine(TractorBeamHaptics());
                    UpdateVRHUD("TRACTOR BEAM ACTIVE", "ANOMALOUS ENERGY FIELD");
                    break;

                case AbductionPhase.AbductHumans:
                    StopHaptics();
                    _hapticCoroutine = StartCoroutine(AbductionHapticBursts());
                    UpdateVRHUD("ABDUCTION IN PROGRESS", "3 HUMANS ACQUIRED");
                    break;

                case AbductionPhase.Ascend:
                    _hapticBeamActive = false;
                    StopHaptics();
                    UpdateVRHUD("CRAFT ASCENDING", "MISSION COMPLETE");
                    break;

                case AbductionPhase.Complete:
                    vrHUDCanvas?.gameObject.SetActive(false);
                    StartCoroutine(FadeToEnd());
                    break;
            }
        }

        // ── Haptics ───────────────────────────────────────────────────────────

        IEnumerator TractorBeamHaptics()
        {
            while (_hapticBeamActive)
            {
                float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 4f);
                float intensity = beamHapticIntensity * pulse;
                SendHapticImpulse(intensity, 0.05f);
                yield return new WaitForSeconds(0.05f);
            }
        }

        IEnumerator AbductionHapticBursts()
        {
            for (int burst = 0; burst < 5; burst++)
            {
                SendHapticImpulse(abductionHapticIntensity, 0.2f);
                yield return new WaitForSeconds(0.2f);
                SendHapticImpulse(0f, 0f);
                yield return new WaitForSeconds(0.15f);
            }
            yield return new WaitForSeconds(1f);
            StartCoroutine(TractorBeamHaptics()); // Resume gentle haptics
        }

        IEnumerator GroundRumbleHaptics(float duration)
        {
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / duration;
                float rumble = Mathf.Sin(t * Mathf.PI) * groundRumbleHapticIntensity;
                rumble += Random.Range(-0.05f, 0.05f);
                SendHapticImpulse(Mathf.Max(0f, rumble), 0.05f);
                yield return new WaitForSeconds(0.05f);
            }
        }

        void SendHapticImpulse(float amplitude, float duration)
        {
            // Refresh devices in case they reconnected
            if (!_leftDevice.isValid)
                _leftDevice = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
            if (!_rightDevice.isValid)
                _rightDevice = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);

            HapticCapabilities caps;
            if (_leftDevice.TryGetHapticCapabilities(out caps) && caps.supportsImpulse)
                _leftDevice.SendHapticImpulse(0, amplitude, duration);
            if (_rightDevice.TryGetHapticCapabilities(out caps) && caps.supportsImpulse)
                _rightDevice.SendHapticImpulse(0, amplitude, duration);
        }

        void StopHaptics()
        {
            _hapticBeamActive = false;
            if (_hapticCoroutine != null) { StopCoroutine(_hapticCoroutine); _hapticCoroutine = null; }
            SendHapticImpulse(0f, 0f);
        }

        // ── Camera Shake ──────────────────────────────────────────────────────

        public void ApplyVRCameraShake(float intensity)
        {
            // VR camera shake: subtle, only on local position (not head tracking)
            Vector3 shake = new Vector3(
                Random.Range(-intensity, intensity),
                Random.Range(-intensity, intensity) * 0.5f,
                Random.Range(-intensity, intensity) * 0.2f
            );
            vrCamera.transform.localPosition = Vector3.Lerp(
                vrCamera.transform.localPosition,
                _originalCameraLocalPos + shake,
                0.5f
            );
        }

        // ── Auto Look (cinematic) ─────────────────────────────────────────────

        void UpdateAutoLook()
        {
            var shipCtrl = GameManager.Instance.spaceshipController;
            if (!shipCtrl) return;

            var phase = GameManager.Instance.CurrentPhase;
            if (phase == AbductionPhase.ApproachFromSpace || phase == AbductionPhase.AtmosphericEntry)
            {
                // Subtly guide player's gaze toward ship
                // (only nudge the rig, not override head tracking)
            }
        }

        // ── VR HUD ────────────────────────────────────────────────────────────

        void UpdateVRHUD(string phase, string status)
        {
            if (vrPhaseText) vrPhaseText.text = phase;
            if (vrTelemetryText) vrTelemetryText.text = status;
        }

        // ── Intro / Outro ──────────────────────────────────────────────────────

        IEnumerator VRIntroSequence()
        {
            yield return new WaitForSeconds(1.5f);
            GameManager.Instance?.StartExperience();
        }

        IEnumerator FadeToEnd()
        {
            yield return new WaitForSeconds(5f);
            GameManager.Instance?.RestartExperience();
        }

        void OnDestroy()
        {
            GameManager.Instance?.OnPhaseChanged.RemoveListener(OnPhaseChanged);
        }
    }
}
