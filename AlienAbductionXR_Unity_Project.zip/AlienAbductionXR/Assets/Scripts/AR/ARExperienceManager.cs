using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using TMPro;
using AlienAbductionXR.Core;

namespace AlienAbductionXR.AR
{
    /// <summary>
    /// ARExperienceManager
    /// Full AR setup: plane detection, placement, scale mode,
    /// UI prompts, and world anchoring.
    /// Supports both table-top and room-scale AR.
    /// </summary>
    [RequireComponent(typeof(ARRaycastManager))]
    [RequireComponent(typeof(ARPlaneManager))]
    public class ARExperienceManager : MonoBehaviour
    {
        public enum ARScaleMode { TableTop, RoomScale, FullScale }

        [Header("AR Components")]
        public ARRaycastManager raycastManager;
        public ARPlaneManager planeManager;
        public ARAnchorManager anchorManager;
        public ARSession arSession;
        public Camera arCamera;

        [Header("Prefabs")]
        public GameObject sceneRootPrefab;     // House + environment
        public GameObject spaceshipPrefab;

        [Header("UI")]
        public GameObject scanningUI;
        public GameObject placementUI;
        public GameObject experienceUI;
        public TextMeshProUGUI instructionText;
        public TextMeshProUGUI trackingStatusText;
        public GameObject scaleModeButtons;

        [Header("Scale Modes")]
        public ARScaleMode currentScaleMode = ARScaleMode.TableTop;
        public float tableTopScale = 0.04f;
        public float roomScale = 0.25f;
        public float fullScale = 1.0f;

        [Header("Placement Indicator")]
        public GameObject placementIndicatorPrefab; // Reticle / ring
        private GameObject _placementIndicator;

        // ── Private ───────────────────────────────────────────────────────────
        private bool _scenePlaced = false;
        private bool _planesFound = false;
        private GameObject _placedScene;
        private GameObject _spaceshipInstance;
        private ARAnchor _sceneAnchor;
        private List<ARRaycastHit> _hits = new List<ARRaycastHit>();

        // ── Lifecycle ──────────────────────────────────────────────────────────

        void Start()
        {
            scanningUI?.SetActive(true);
            placementUI?.SetActive(false);
            experienceUI?.SetActive(false);
            scaleModeButtons?.SetActive(false);

            planeManager.planesChanged += OnPlanesChanged;

            if (placementIndicatorPrefab)
                _placementIndicator = Instantiate(placementIndicatorPrefab);

            SetInstruction("Move your phone slowly to scan surfaces...");
            StartCoroutine(TrackingStatusLoop());
        }

        void Update()
        {
            if (_scenePlaced) return;

            UpdatePlacementIndicator();
            HandlePlacementInput();
        }

        // ── Plane Detection ───────────────────────────────────────────────────

        void OnPlanesChanged(ARPlanesChangedEventArgs args)
        {
            if (args.added.Count > 0 && !_planesFound)
            {
                _planesFound = true;
                scanningUI?.SetActive(false);
                placementUI?.SetActive(true);
                scaleModeButtons?.SetActive(true);
                SetInstruction("Tap a flat surface to place the experience");
            }
        }

        // ── Placement Indicator ───────────────────────────────────────────────

        void UpdatePlacementIndicator()
        {
            Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
            if (raycastManager.Raycast(screenCenter, _hits, TrackableType.PlaneWithinPolygon))
            {
                Pose hit = _hits[0].pose;
                if (_placementIndicator)
                {
                    _placementIndicator.SetActive(true);
                    _placementIndicator.transform.position = hit.position;
                    _placementIndicator.transform.rotation = hit.rotation;
                    // Pulse scale
                    float pulse = 1f + 0.08f * Mathf.Sin(Time.time * 3f);
                    _placementIndicator.transform.localScale = Vector3.one * GetCurrentScale() * 30f * pulse;
                }
            }
            else
            {
                _placementIndicator?.SetActive(false);
            }
        }

        // ── Input ─────────────────────────────────────────────────────────────

        void HandlePlacementInput()
        {
            bool tapped = false;
            Vector2 tapPos = Vector2.zero;

#if UNITY_EDITOR
            if (Input.GetMouseButtonDown(0))
            { tapped = true; tapPos = Input.mousePosition; }
#else
            if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
            { tapped = true; tapPos = Input.GetTouch(0).position; }
#endif

            if (tapped)
            {
                if (raycastManager.Raycast(tapPos, _hits, TrackableType.PlaneWithinPolygon))
                {
                    PlaceExperience(_hits[0].pose, _hits[0].trackableId);
                }
            }
        }

        // ── Place Experience ──────────────────────────────────────────────────

        void PlaceExperience(Pose hitPose, TrackableId planeId)
        {
            _scenePlaced = true;
            placementUI?.SetActive(false);
            experienceUI?.SetActive(true);
            scaleModeButtons?.SetActive(false);
            _placementIndicator?.SetActive(false);

            // Hide planes
            planeManager.enabled = false;
            foreach (var p in planeManager.trackables) p.gameObject.SetActive(false);

            // Create anchor for world-locked placement
            var plane = planeManager.GetPlane(planeId);
            if (plane != null && anchorManager != null)
                _sceneAnchor = anchorManager.AttachAnchor(plane, hitPose);

            float scale = GetCurrentScale();

            // Spawn scene root
            _placedScene = Instantiate(sceneRootPrefab, hitPose.position, hitPose.rotation);
            _placedScene.transform.localScale = Vector3.one * scale;

            // Spawn spaceship high above
            Vector3 spawnPos = hitPose.position + Vector3.up * (600f * scale);
            _spaceshipInstance = Instantiate(spaceshipPrefab, spawnPos, Quaternion.identity);

            // Wire all references via GameManager
            var gm = GameManager.Instance;
            if (gm)
            {
                gm.environmentManager.earthCenter = _placedScene.transform;
                gm.environmentManager.houseTransform = _placedScene.transform.Find("HouseRoot");
                gm.spaceshipController = _spaceshipInstance.GetComponent<SpaceshipController>();
                gm.spaceshipController.settings = gm.settings;

                // Find humans
                Transform humanParent = _placedScene.transform.Find("Humans");
                if (humanParent != null)
                {
                    gm.sequenceDirector.humans.Clear();
                    for (int i = 0; i < humanParent.childCount; i++)
                    {
                        var h = humanParent.GetChild(i).GetComponent<HumanAbductionBehavior>();
                        if (h) gm.sequenceDirector.humans.Add(h);
                    }
                }

                gm.StartExperience();
            }

            SetInstruction("");
        }

        // ── Scale Mode ────────────────────────────────────────────────────────

        public void SetScaleMode(int mode)
        {
            currentScaleMode = (ARScaleMode)mode;
            string label = currentScaleMode switch
            {
                ARScaleMode.TableTop => "Table-Top Mode (40mm)",
                ARScaleMode.RoomScale => "Room Scale (25cm)",
                ARScaleMode.FullScale => "Full Scale (1:1)",
                _ => ""
            };
            SetInstruction($"{label} — Tap to place");
        }

        float GetCurrentScale()
        {
            return currentScaleMode switch
            {
                ARScaleMode.TableTop => tableTopScale,
                ARScaleMode.RoomScale => roomScale,
                ARScaleMode.FullScale => fullScale,
                _ => tableTopScale
            };
        }

        // ── Tracking Status ───────────────────────────────────────────────────

        IEnumerator TrackingStatusLoop()
        {
            while (true)
            {
                if (trackingStatusText)
                {
                    var state = ARSession.state;
                    trackingStatusText.text = state switch
                    {
                        ARSessionState.SessionTracking => "● AR TRACKING",
                        ARSessionState.SessionInitializing => "◌ INITIALIZING",
                        ARSessionState.Unsupported => "✗ NOT SUPPORTED",
                        _ => "◌ WAITING"
                    };
                }
                yield return new WaitForSeconds(0.5f);
            }
        }

        void SetInstruction(string text)
        {
            if (instructionText) instructionText.text = text;
        }

        void OnDestroy()
        {
            if (planeManager) planeManager.planesChanged -= OnPlanesChanged;
        }
    }
}
