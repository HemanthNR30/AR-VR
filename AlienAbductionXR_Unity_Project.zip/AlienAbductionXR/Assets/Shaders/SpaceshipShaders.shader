// ============================================================
// TRACTOR BEAM SHADER — Unity URP
// Animated energy beam with scanlines, fresnel, energy rings
// ============================================================
Shader "AlienAbductionXR/TractorBeam"
{
    Properties
    {
        _BeamColor      ("Beam Color",          Color)  = (0.1, 0.85, 1.0, 0.35)
        _ScanSpeed      ("Scan Speed",          Float)  = 2.5
        _ScanFreq       ("Scan Frequency",      Float)  = 18.0
        _NoiseScale     ("Noise Scale",         Float)  = 6.0
        _PulseSpeed     ("Pulse Speed",         Float)  = 3.5
        _EdgePower      ("Edge Falloff Power",  Float)  = 2.5
        _EmissionMult   ("Emission Multiplier", Float)  = 2.5
        _RingCount      ("Energy Ring Count",   Float)  = 3.0
        _RingSpeed      ("Energy Ring Speed",   Float)  = 0.7
    }

    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" }
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        Cull Off

        Pass
        {
            Name "TractorBeam"
            HLSLPROGRAM
            #pragma vertex   TractorVert
            #pragma fragment TractorFrag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes {
                float4 posOS : POSITION;
                float2 uv    : TEXCOORD0;
                float3 normOS: NORMAL;
            };
            struct Varyings {
                float4 posCS  : SV_POSITION;
                float2 uv     : TEXCOORD0;
                float3 worldP : TEXCOORD1;
                float3 viewD  : TEXCOORD2;
                float3 normWS : TEXCOORD3;
            };

            CBUFFER_START(UnityPerMaterial)
                float4 _BeamColor;
                float  _ScanSpeed, _ScanFreq, _NoiseScale;
                float  _PulseSpeed, _EdgePower, _EmissionMult;
                float  _RingCount, _RingSpeed;
            CBUFFER_END

            // Hash noise
            float hash21(float2 p) { return frac(sin(dot(p,float2(127.1,311.7)))*43758.5453); }
            float smoothNoise(float2 p) {
                float2 i=floor(p), f=frac(p), u=f*f*(3-2*f);
                return lerp(lerp(hash21(i),hash21(i+float2(1,0)),u.x),
                            lerp(hash21(i+float2(0,1)),hash21(i+float2(1,1)),u.x),u.y);
            }

            Varyings TractorVert(Attributes IN) {
                Varyings OUT;
                OUT.posCS  = TransformObjectToHClip(IN.posOS.xyz);
                OUT.uv     = IN.uv;
                OUT.worldP = TransformObjectToWorld(IN.posOS.xyz);
                OUT.normWS = TransformObjectToWorldNormal(IN.normOS);
                OUT.viewD  = GetWorldSpaceViewDir(OUT.worldP);
                return OUT;
            }

            half4 TractorFrag(Varyings IN) : SV_Target {
                float t = _Time.y;
                float2 uv = IN.uv;

                // Scanlines moving downward
                float scan = sin(uv.y * _ScanFreq - t * _ScanSpeed);
                scan = pow(saturate(scan * 0.5 + 0.5), 3.0);

                // Layered noise for energy turbulence
                float2 nuv = uv * _NoiseScale + float2(0, t * 0.4);
                float n = smoothNoise(nuv) * 0.6
                        + smoothNoise(nuv * 2.1 + float2(t*0.3, 0)) * 0.3
                        + smoothNoise(nuv * 4.3 - float2(0, t*0.2)) * 0.1;

                // Fresnel edge glow
                float3 nN = normalize(IN.normWS);
                float3 vD = normalize(IN.viewD);
                float fresnel = pow(1.0 - abs(dot(nN, vD)), _EdgePower);

                // Pulse rings flowing downward
                float rings = 0;
                for(float i=0; i<_RingCount; i++) {
                    float rp = frac(uv.y - t * _RingSpeed + i / _RingCount);
                    rings += smoothstep(0.02, 0.0, abs(rp - 0.5) - 0.45) * 0.4;
                }

                // Overall pulse
                float pulse = 0.5 + 0.5 * sin(t * _PulseSpeed);

                // Combine alpha layers
                float alpha = (fresnel * 0.5 + scan * 0.2 + n * 0.15 + rings * 0.15 + pulse * 0.1)
                            * _BeamColor.a;
                alpha = saturate(alpha);

                // Color: core cyan + energy noise offset
                float3 col = _BeamColor.rgb * _EmissionMult;
                col += float3(0.05, 0.3, 0.5) * n * pulse;
                col += float3(0.1, 0.5, 0.8) * rings;

                return half4(col, alpha);
            }
            ENDHLSL
        }
    }
}


// ============================================================
// SPACESHIP HULL SHADER — Unity URP
// PBR-based metallic hull with rim light and emissive strips
// ============================================================
Shader "AlienAbductionXR/SpaceshipHull"
{
    Properties
    {
        _BaseColor      ("Base Color",          Color)      = (0.15, 0.18, 0.25, 1)
        _BaseMap        ("Albedo Texture",      2D)         = "white" {}
        _MetallicMap    ("Metallic/Smoothness", 2D)         = "white" {}
        _NormalMap      ("Normal Map",          2D)         = "bump"  {}
        _EmissionMap    ("Emission Map",        2D)         = "black" {}
        _Metallic       ("Metallic",            Range(0,1)) = 0.9
        _Smoothness     ("Smoothness",          Range(0,1)) = 0.7
        _EmissionColor  ("Emission Color",      Color)      = (0.0, 0.5, 1.0, 1.0)
        _EmissionPulse  ("Emission Pulse Speed",Float)      = 2.0
        _RimColor       ("Rim Light Color",     Color)      = (0.3, 0.8, 1.0, 1.0)
        _RimPower       ("Rim Power",           Float)      = 3.0
        _RimIntensity   ("Rim Intensity",       Float)      = 1.5
        _PanelLineColor ("Panel Line Color",    Color)      = (0.4, 0.6, 0.8, 0.5)
    }

    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode" = "UniversalForward" }

            HLSLPROGRAM
            #pragma vertex   HullVert
            #pragma fragment HullFrag
            #pragma multi_compile_fog
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            struct Attributes {
                float4 posOS   : POSITION;
                float3 normOS  : NORMAL;
                float4 tangOS  : TANGENT;
                float2 uv      : TEXCOORD0;
            };
            struct Varyings {
                float4 posCS   : SV_POSITION;
                float2 uv      : TEXCOORD0;
                float3 worldP  : TEXCOORD1;
                float3 normWS  : TEXCOORD2;
                float3 viewD   : TEXCOORD3;
                float  fogFact : TEXCOORD4;
            };

            CBUFFER_START(UnityPerMaterial)
                float4 _BaseColor;
                float4 _EmissionColor;
                float4 _RimColor;
                float4 _PanelLineColor;
                float  _Metallic, _Smoothness;
                float  _EmissionPulse, _RimPower, _RimIntensity;
            CBUFFER_END

            TEXTURE2D(_BaseMap);    SAMPLER(sampler_BaseMap);
            TEXTURE2D(_NormalMap);  SAMPLER(sampler_NormalMap);
            TEXTURE2D(_EmissionMap);SAMPLER(sampler_EmissionMap);

            Varyings HullVert(Attributes IN) {
                Varyings OUT;
                OUT.posCS  = TransformObjectToHClip(IN.posOS.xyz);
                OUT.uv     = IN.uv;
                OUT.worldP = TransformObjectToWorld(IN.posOS.xyz);
                OUT.normWS = TransformObjectToWorldNormal(IN.normOS);
                OUT.viewD  = GetWorldSpaceViewDir(OUT.worldP);
                OUT.fogFact = ComputeFogFactor(OUT.posCS.z);
                return OUT;
            }

            half4 HullFrag(Varyings IN) : SV_Target {
                float t = _Time.y;

                // Base color + texture
                float4 baseCol = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, IN.uv) * _BaseColor;

                // Normal
                float3 normWS = normalize(IN.normWS);
                float3 viewD  = normalize(IN.viewD);

                // Rim light (alien craft edge glow)
                float rimDot = 1.0 - saturate(dot(normWS, viewD));
                float rim = pow(rimDot, _RimPower) * _RimIntensity;

                // Emission (pulsing panels)
                float4 emissMap = SAMPLE_TEXTURE2D(_EmissionMap, sampler_EmissionMap, IN.uv);
                float  emPulse  = 0.5 + 0.5 * sin(t * _EmissionPulse);
                float3 emission = emissMap.rgb * _EmissionColor.rgb * (0.7 + emPulse * 0.6);
                emission += _RimColor.rgb * rim;

                // Basic diffuse lighting
                Light mainLight = GetMainLight();
                float NdotL = saturate(dot(normWS, mainLight.direction));
                float3 diffuse = baseCol.rgb * mainLight.color * NdotL;
                float3 ambient = SampleSH(normWS) * baseCol.rgb * 0.3;

                // Specular (simple Blinn-Phong)
                float3 halfV = normalize(mainLight.direction + viewD);
                float spec = pow(saturate(dot(normWS, halfV)), _Smoothness * 128.0) * _Metallic;
                float3 specular = spec * mainLight.color * _Metallic;

                float3 finalColor = diffuse + ambient + specular + emission;

                // Fog
                finalColor = MixFog(finalColor, IN.fogFact);

                return half4(finalColor, 1.0);
            }
            ENDHLSL
        }
    }
    FallBack "Universal Render Pipeline/Lit"
}
