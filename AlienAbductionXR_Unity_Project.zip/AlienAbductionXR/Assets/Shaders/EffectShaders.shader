// ============================================================
// WARP STREAK SHADER — Unity URP
// Elongated star streaks during warp jump departure
// ============================================================
Shader "AlienAbductionXR/WarpStreak"
{
    Properties
    {
        _StreakColor  ("Streak Color",    Color)  = (0.8, 0.95, 1.0, 1.0)
        _StreakSpeed  ("Streak Speed",    Float)  = 5.0
        _StreakLength ("Streak Length",   Float)  = 0.95
        _Brightness   ("Brightness",      Float)  = 3.0
        _Intensity    ("Intensity",       Range(0,1)) = 0.0
    }
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" }
        Blend One One
        ZWrite Off
        Cull Off

        Pass
        {
            HLSLPROGRAM
            #pragma vertex   WarpVert
            #pragma fragment WarpFrag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes { float4 pos:POSITION; float2 uv:TEXCOORD0; };
            struct Varyings   { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; };

            CBUFFER_START(UnityPerMaterial)
                float4 _StreakColor;
                float  _StreakSpeed, _StreakLength, _Brightness, _Intensity;
            CBUFFER_END

            float hash(float2 p) { return frac(sin(dot(p,float2(127.1,311.7)))*43758.5); }

            Varyings WarpVert(Attributes IN) {
                Varyings OUT;
                OUT.pos = TransformObjectToHClip(IN.pos.xyz);
                OUT.uv  = IN.uv;
                return OUT;
            }

            half4 WarpFrag(Varyings IN) : SV_Target {
                float2 uv = IN.uv * 2.0 - 1.0;
                float t   = _Time.y;

                float glow = 0.0;

                // Generate multiple streaks
                for(int i = 0; i < 30; i++) {
                    float fi = float(i);
                    float2 seed = float2(fi * 0.371, fi * 0.618);
                    float sx = hash(seed) * 2.0 - 1.0;
                    float sy = hash(seed + 0.5) * 2.0 - 1.0;

                    // Streak extends from center outward
                    float2 dir = normalize(float2(sx, sy));
                    float2 perp = float2(-dir.y, dir.x);

                    float2 diff = uv - float2(sx, sy) * 0.1;
                    float along = dot(diff, dir);
                    float across = dot(diff, perp);

                    float streakT = frac(along * _StreakSpeed - t * _StreakSpeed + fi * 0.37);
                    float streakA = step(1.0 - _StreakLength, streakT) * smoothstep(1.0, 1.0 - _StreakLength, streakT);
                    float width   = smoothstep(0.003, 0.0, abs(across));

                    glow += streakA * width * _Brightness;
                }

                float3 col = _StreakColor.rgb * glow * _Intensity;
                return half4(col, glow * _Intensity * 0.8);
            }
            ENDHLSL
        }
    }
}


// ============================================================
// HOLOGRAPHIC HUMAN SHADER — Unity URP
// Used on humans when tractor beam captures them
// Scanline hologram with glitch and dissolve
// ============================================================
Shader "AlienAbductionXR/HolographicHuman"
{
    Properties
    {
        _MainTex        ("Albedo",          2D)         = "white" {}
        _HoloColor      ("Hologram Color",  Color)      = (0.1, 0.9, 1.0, 1.0)
        _ScanSpeed      ("Scan Speed",      Float)      = 3.0
        _GlitchStrength ("Glitch Strength", Float)      = 0.02
        _DissolveAmount ("Dissolve",        Range(0,1)) = 0.0
        _FresnelPower   ("Fresnel Power",   Float)      = 2.0
        _NoiseTex       ("Noise Texture",   2D)         = "white" {}
    }
    SubShader
    {
        Tags { "Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" }
        Blend SrcAlpha OneMinusSrcAlpha
        ZWrite Off
        Cull Off

        Pass
        {
            HLSLPROGRAM
            #pragma vertex   HoloVert
            #pragma fragment HoloFrag
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes { float4 pos:POSITION; float2 uv:TEXCOORD0; float3 norm:NORMAL; };
            struct Varyings   { float4 pos:SV_POSITION; float2 uv:TEXCOORD0; float3 normWS:TEXCOORD1; float3 viewD:TEXCOORD2; };

            CBUFFER_START(UnityPerMaterial)
                float4 _HoloColor;
                float  _ScanSpeed, _GlitchStrength, _DissolveAmount, _FresnelPower;
            CBUFFER_END

            TEXTURE2D(_MainTex);  SAMPLER(sampler_MainTex);
            TEXTURE2D(_NoiseTex); SAMPLER(sampler_NoiseTex);

            float hash(float2 p) { return frac(sin(dot(p,float2(127.1,311.7)))*43758.5); }

            Varyings HoloVert(Attributes IN) {
                Varyings OUT;
                // Glitch vertex offset
                float t = _Time.y;
                float glitch = hash(float2(floor(IN.pos.y*10),floor(t*15))) * _GlitchStrength;
                float3 pos = IN.pos.xyz + IN.norm * glitch * 0.5;
                OUT.pos    = TransformObjectToHClip(pos);
                OUT.uv     = IN.uv;
                OUT.normWS = TransformObjectToWorldNormal(IN.norm);
                OUT.viewD  = GetWorldSpaceViewDir(TransformObjectToWorld(IN.pos.xyz));
                return OUT;
            }

            half4 HoloFrag(Varyings IN) : SV_Target {
                float t = _Time.y;

                // Original texture
                float4 col = SAMPLE_TEXTURE2D(_MainTex, sampler_MainTex, IN.uv);

                // Scanlines
                float scan = sin(IN.uv.y * 60.0 - t * _ScanSpeed) * 0.5 + 0.5;
                scan = pow(scan, 3.0);

                // Fresnel glow on edges
                float3 nN = normalize(IN.normWS);
                float3 vD = normalize(IN.viewD);
                float fresnel = pow(1.0 - abs(dot(nN, vD)), _FresnelPower);

                // Dissolve (noise threshold)
                float noise = SAMPLE_TEXTURE2D(_NoiseTex, sampler_NoiseTex, IN.uv * 3.0).r;
                float dissolveAlpha = step(_DissolveAmount, noise);

                // Hologram tint
                float3 holoCol = lerp(col.rgb, _HoloColor.rgb, 0.7);
                holoCol += _HoloColor.rgb * scan * 0.3;
                holoCol += _HoloColor.rgb * fresnel * 1.5;

                float alpha = (col.a * dissolveAlpha) * (0.6 + scan * 0.3 + fresnel * 0.3);

                return half4(holoCol, saturate(alpha));
            }
            ENDHLSL
        }
    }
}
