using UnityEngine;
using UnityEditor;
using AlienAbductionXR.Core;
using AlienAbductionXR.UI;

namespace AlienAbductionXR.Editor
{
    /// <summary>
    /// AlienAbductionXR Scene Setup Tool
    /// Unity Editor window that auto-wires all scene references.
    /// Open via: Window > AlienAbductionXR > Scene Setup Tool
    /// </summary>
    public class SceneSetupTool : EditorWindow
    {
        [MenuItem("Window/AlienAbductionXR/Scene Setup Tool")]
        public static void OpenWindow()
        {
            GetWindow<SceneSetupTool>("XR Scene Setup").Show();
        }

        private bool _showSpaceship = true;
        private bool _showEnvironment = true;
        private bool _showPostFX = true;
        private bool _showAudio = true;

        void OnGUI()
        {
            GUILayout.Label("ALIEN ABDUCTION XR — SCENE SETUP", EditorStyles.boldLabel);
            EditorGUILayout.Space();

            EditorGUILayout.HelpBox(
                "This tool auto-wires all script references in your scene.\n" +
                "Make sure you have placed all required prefabs before running.",
                MessageType.Info);

            EditorGUILayout.Space();

            if (GUILayout.Button("▶  AUTO-SETUP ENTIRE SCENE", GUILayout.Height(40)))
                AutoSetupScene();

            EditorGUILayout.Space();
            DrawSectionHeader("INDIVIDUAL SETUP", ref _showSpaceship);
            if (_showSpaceship)
            {
                if (GUILayout.Button("Setup Spaceship")) SetupSpaceship();
                if (GUILayout.Button("Setup Humans")) SetupHumans();
            }

            DrawSectionHeader("ENVIRONMENT", ref _showEnvironment);
            if (_showEnvironment)
            {
                if (GUILayout.Button("Setup Environment Manager")) SetupEnvironment();
                if (GUILayout.Button("Add Ground Shake to Camera")) SetupCameraShake();
            }

            DrawSectionHeader("POST PROCESSING", ref _showPostFX);
            if (_showPostFX)
            {
                if (GUILayout.Button("Create URP Post Processing Volume")) CreatePostVolume();
            }

            DrawSectionHeader("AUDIO", ref _showAudio);
            if (_showAudio)
            {
                if (GUILayout.Button("Setup Audio Manager")) SetupAudio();
            }

            EditorGUILayout.Space();
            if (GUILayout.Button("Validate Scene (Check Missing References)"))
                ValidateScene();
        }

        void DrawSectionHeader(string title, ref bool foldout)
        {
            EditorGUILayout.Space(4);
            foldout = EditorGUILayout.Foldout(foldout, title, true, EditorStyles.foldoutHeader);
        }

        void AutoSetupScene()
        {
            SetupSpaceship();
            SetupHumans();
            SetupEnvironment();
            SetupCameraShake();
            SetupAudio();
            ValidateScene();
            Debug.Log("[SceneSetupTool] Auto-setup complete!");
        }

        void SetupSpaceship()
        {
            var ship = FindFirstObjectByType<SpaceshipController>();
            if (!ship) { Debug.LogWarning("[Setup] No SpaceshipController found."); return; }

            // Auto-find child transforms by name
            ship.tractorBeamOrigin = ship.transform.Find("TractorBeamOrigin");
            ship.tractorBeamConeMesh = ship.transform.Find("TractorBeamCone")?.gameObject;
            ship.tractorBeamLight = ship.transform.Find("TractorBeamLight")?.GetComponent<Light>();
            ship.domeMesh = ship.transform.Find("Dome");
            ship.tractorBeamParticles = ship.transform.Find("TractorBeamParticles")?.GetComponent<ParticleSystem>();
            ship.atmosphericEntryFireFX = ship.transform.Find("EntryFireFX")?.GetComponent<ParticleSystem>();

            var engineParent = ship.transform.Find("Engines");
            if (engineParent != null)
            {
                ship.enginePods = new Transform[engineParent.childCount];
                for (int i = 0; i < engineParent.childCount; i++)
                    ship.enginePods[i] = engineParent.GetChild(i);

                var fxList = new System.Collections.Generic.List<ParticleSystem>();
                foreach (Transform ep in engineParent)
                {
                    var ps = ep.GetComponentInChildren<ParticleSystem>();
                    if (ps) fxList.Add(ps);
                }
                ship.engineThrusterFX = fxList.ToArray();
            }

            var lightParent = ship.transform.Find("RunningLights");
            if (lightParent != null)
            {
                var lights = new System.Collections.Generic.List<Light>();
                foreach (Transform l in lightParent)
                {
                    var ll = l.GetComponent<Light>();
                    if (ll) lights.Add(ll);
                }
                ship.runningLights = lights.ToArray();
            }

            EditorUtility.SetDirty(ship);
            Debug.Log("[Setup] Spaceship references wired.");
        }

        void SetupHumans()
        {
            var humans = FindObjectsByType<HumanAbductionBehavior>(FindObjectsSortMode.None);
            foreach (var h in humans)
            {
                h.animator = h.GetComponent<Animator>() ?? h.GetComponentInChildren<Animator>();
                h.navAgent = h.GetComponent<NavMeshAgent>();
                h.rb = h.GetComponent<Rigidbody>();
                h.audio = h.GetComponent<AudioSource>() ?? h.gameObject.AddComponent<AudioSource>();
                h.meshRenderer = h.GetComponentInChildren<SkinnedMeshRenderer>();
                h.bodyCollider = h.GetComponent<Collider>() ?? h.GetComponentInChildren<Collider>();
                h.tractorGlowFX = h.transform.Find("TractorGlowFX")?.GetComponent<ParticleSystem>();
                h.personalBeamLight = h.transform.Find("BeamLight")?.GetComponent<Light>();
                EditorUtility.SetDirty(h);
            }
            Debug.Log($"[Setup] {humans.Length} humans wired.");
        }

        void SetupEnvironment()
        {
            var env = FindFirstObjectByType<EnvironmentManager>();
            if (!env) { Debug.LogWarning("[Setup] No EnvironmentManager found."); return; }

            env.earthCenter = GameObject.Find("EarthCenter")?.transform;
            env.houseTransform = GameObject.Find("HouseRoot")?.transform;
            env.groundPlane = GameObject.Find("GroundPlane")?.transform;
            env.groundSceneRoot = GameObject.Find("GroundSceneRoot");
            env.earthOrb = GameObject.Find("EarthOrb");
            env.moonOrb = GameObject.Find("MoonOrb");
            env.cityLightsParent = GameObject.Find("CityLights");

            var winLights = new System.Collections.Generic.List<Light>();
            var winParent = GameObject.Find("WindowLights");
            if (winParent != null)
                foreach (Transform wl in winParent.transform)
                { var l = wl.GetComponent<Light>(); if (l) winLights.Add(l); }
            env.windowLights = winLights.ToArray();

            EditorUtility.SetDirty(env);
            Debug.Log("[Setup] Environment Manager wired.");
        }

        void SetupCameraShake()
        {
            var cam = FindFirstObjectByType<CinematicCameraController>();
            if (!cam) { Debug.LogWarning("[Setup] No CinematicCameraController found."); return; }
            cam.mainCamera = Camera.main;
            cam.cameraRig = Camera.main?.transform.parent;
            EditorUtility.SetDirty(cam);
        }

        void SetupAudio()
        {
            var audio = FindFirstObjectByType<AudioManager>();
            if (!audio) { Debug.LogWarning("[Setup] No AudioManager found."); return; }

            // Auto-assign audio sources by tag
            var sources = FindObjectsByType<AudioSource>(FindObjectsSortMode.None);
            foreach (var s in sources)
            {
                if (s.gameObject.CompareTag("EngineAudio")) audio.engineSource = s;
                else if (s.gameObject.CompareTag("AmbientAudio")) audio.ambientSource = s;
                else if (s.gameObject.CompareTag("MusicAudio")) audio.musicSource = s;
                else if (s.gameObject.CompareTag("BeamAudio")) audio.tractorBeamSource = s;
                else if (s.gameObject.CompareTag("SFXAudio")) audio.sfxSource = s;
            }
            EditorUtility.SetDirty(audio);
            Debug.Log("[Setup] Audio Manager wired.");
        }

        void CreatePostVolume()
        {
            var vol = FindFirstObjectByType<UnityEngine.Rendering.Volume>();
            if (vol)
            {
                Debug.Log("[Setup] Post Processing Volume already exists.");
                return;
            }
            var go = new GameObject("GlobalPostProcessVolume");
            var v = go.AddComponent<UnityEngine.Rendering.Volume>();
            v.isGlobal = true;
            v.priority = 10f;
            go.AddComponent<PostProcessingController>();
            Debug.Log("[Setup] Global Post Processing Volume created. Assign a URP Volume Profile to it.");
        }

        void ValidateScene()
        {
            int issues = 0;

            void Check(Object obj, string name)
            { if (!obj) { Debug.LogError($"[Validate] MISSING: {name}"); issues++; } }

            Check(FindFirstObjectByType<GameManager>(), "GameManager");
            Check(FindFirstObjectByType<AbductionSequenceDirector>(), "AbductionSequenceDirector");
            Check(FindFirstObjectByType<SpaceshipController>(), "SpaceshipController");
            Check(FindFirstObjectByType<EnvironmentManager>(), "EnvironmentManager");
            Check(FindFirstObjectByType<PostProcessingController>(), "PostProcessingController");
            Check(FindFirstObjectByType<AudioManager>(), "AudioManager");

            int humans = FindObjectsByType<HumanAbductionBehavior>(FindObjectsSortMode.None).Length;
            if (humans == 0) { Debug.LogWarning("[Validate] No HumanAbductionBehavior found! Add at least 1 human."); issues++; }

            if (issues == 0)
                Debug.Log("[Validate] ✓ All references valid! Scene ready.");
            else
                Debug.LogError($"[Validate] {issues} issue(s) found. Check console above.");
        }
    }
}
